"""รายงาน: ส่งออก CSV, พิมพ์ทะเบียน, รายงานสรุป"""
import csv
import logging
from datetime import date
from pathlib import Path

from .filters import STATUSES, status_of
from .formats import THAI_FULL, fmt_amount, fmt_thai_date, tick_of


def export_csv(rows, dest: Path) -> int:
    """ส่งออกเป็น CSV (UTF-8 มี BOM เพื่อให้ Excel อ่านภาษาไทยได้)"""
    head = ["ที่", "วันที่จัดทำ", "ฎีกาเรื่อง", "แผนงาน", "งาน", "รายจ่าย", "ประเภทรายจ่าย", "จำนวนเงิน",
            "ผู้ส่งมอบ", "ผู้รับมอบ", "สถานะ", "หมายเหตุ"]
    with open(dest, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(head)
        for r in rows:
            w.writerow([r["no"], fmt_thai_date(r["created"]), r["subject"], r["plan"],
                        r["task"], r["expense_type"], r["expense_item"], f"{r['amount'] / 100:.2f}", tick_of(r["sender"]),
                        tick_of(r["receiver"]), status_of(r), r["note"]])
    logging.info("ส่งออก %s รายการ -> %s", len(rows), dest)
    return len(rows)


# ---------------------------------------------------------------- รายงาน (HTML สำหรับพิมพ์)
_CSS = """
body { font-family: "TH Sarabun New","Sarabun","Tahoma",sans-serif; font-size: 13pt; }
h1 { text-align:center; font-size: 18pt; margin: 0 0 4px; }
h2 { font-size: 14pt; margin: 14px 0 4px; }
.meta { text-align:center; margin-bottom: 8px; }
table { border-collapse: collapse; width: 100%; table-layout: fixed; }
th, td { border: 1px solid #000; padding: 3px 5px; font-size: 9.5pt; vertical-align: top; }
th { background: #eee; } thead { display: table-header-group; } tr { page-break-inside: avoid; }
.c { text-align:center; } .r { text-align:right; white-space: nowrap; }
.nw { white-space: nowrap; }   /* หัวข้อ/ช่องที่ห้ามตัดขึ้นบรรทัดใหม่ */

/* กำหนดความกว้างของคอลัมน์ต่างๆ ให้สมดุลหลังจากเอาวันที่ส่งมอบ/รับมอบออก */
.no-col { width: 4%; }
.date-col { width: 5%; white-space: nowrap; text-align: center; }
.subject { width: 15%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; }
.plan-col { width: 8%; }
.task-col { width: 8%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; }
.expense-col { width: 8.5%; white-space: normal; }
.expense-item-col { width: 8%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; }
.amount-col { width: 8%; text-align: right; white-space: nowrap; }
.sig-col { width: 7%; white-space: nowrap; text-align: center; }
.note-col { width: 8%; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; }
"""


def _page(title, subtitle, rows_count, inner, landscape=True):
    from html import escape as e
    size = "A4 landscape" if landscape else "A4 portrait"
    return f"""<!doctype html><html lang="th"><head><meta charset="utf-8">
<title>{e(title)}</title><style>@page {{ size: {size}; margin: 10mm; }}{_CSS}</style>
</head><body onload="window.print()">
<h1>{e(title)}</h1>
<div class="meta">{("ตัวกรอง: " + e(subtitle) + "<br>") if subtitle else ""}พิมพ์เมื่อ {fmt_thai_date(date.today().isoformat())}
 &nbsp;|&nbsp; จำนวน {rows_count} รายการ</div>
{inner}</body></html>"""


def build_print_html(rows, title="ทะเบียนการจัดทำฎีกา", subtitle="") -> str:
    """ทะเบียน: A4 แนวนอน (ถอดคอลัมน์วันที่ส่งมอบและวันที่รับมอบออกแล้ว)"""
    from html import escape as e
    body = "".join(
        "<tr>" + "".join(f"<td{c}>{e(str(v))}</td>" for v, c in (
            (r["no"], ' class="c no-col"'), 
            (fmt_thai_date(r["created"]), ' class="date-col"'),      # วันที่จัดทำ
            (r["subject"], ' class="subject"'),          # ฎีกาเรื่อง
            (r["plan"], ' class="plan-col"'),            # แผนงาน
            (r["task"], ' class="task-col"'),            # งาน
            (r["expense_type"], ' class="expense-col"'), # รายจ่าย
            (r["expense_item"], ' class="expense-item-col"'), # ประเภทรายจ่าย
            (fmt_amount(r["amount"]), ' class="amount-col"'), # จำนวนเงิน
            (tick_of(r["sender"]), ' class="sig-col"'),      # ผู้ส่งมอบ
            (tick_of(r["receiver"]), ' class="sig-col"'),    # ผู้รับมอบ
            (r["note"], ' class="note-col"'))) + "</tr>" for r in rows)  # หมายเหตุ
            
    inner = f"""<table><thead><tr>
<th class="no-col">ที่</th>
<th class="date-col">วันที่จัดทำ</th>
<th class="subject">ฎีกาเรื่อง</th>
<th class="plan-col">แผนงาน</th>
<th class="task-col">งาน</th>
<th class="expense-col">รายจ่าย</th>
<th class="expense-item-col">ประเภทรายจ่าย</th>
<th class="amount-col">จำนวนเงิน</th>
<th class="sig-col">ผู้ส่งมอบ</th>
<th class="sig-col">ผู้รับมอบ</th>
<th class="note-col">หมายเหตุ</th>
</tr></thead>
<tbody>{body}</tbody>
</table>"""
    return _page(title, subtitle, len(rows), inner, landscape=True)


def group_totals(rows, keyfn):
    """รวมจำนวนรายการ/ยอดเงิน ตามกลุ่ม -> [(กลุ่ม, จำนวน, ยอดเงิน)] เรียงตามกลุ่ม"""
    acc = {}
    for r in rows:
        k = keyfn(r)
        c, t = acc.get(k, (0, 0))
        acc[k] = (c + 1, t + r["amount"])
    return [(k, c, t) for k, (c, t) in sorted(acc.items())]


def summary_sections(rows):
    """ส่วนสรุปทั้งหมด -> [(หัวข้อ, [(ชื่อกลุ่ม, จำนวน, ยอดเงิน)])]"""
    order = {s: i for i, s in enumerate(STATUSES)}
    by_status = [(STATUSES[k], c, t) for k, c, t in group_totals(rows, lambda r: order[status_of(r)])]

    def month_label(ym):
        y, m = ym.split("-")
        return f"{THAI_FULL[int(m)]} {int(y) + 543}"

    return [
        ("สรุปตามสถานะ", by_status),
        ("สรุปตามแผนงาน", group_totals(rows, lambda r: r["plan"])),
        ("สรุปตามแผนงานและงาน", group_totals(rows, lambda r: r["plan"] + (" › " + r["task"] if r["task"] else ""))),
        ("สรุปตามรายจ่าย", group_totals(rows, lambda r: r["expense_type"])),
        ("สรุปตามรายจ่ายและประเภทรายจ่าย",
         group_totals(rows, lambda r: r["expense_type"] + (" › " + r["expense_item"] if r["expense_item"] else ""))),
        ("สรุปตามเดือนที่จัดทำ", [(month_label(k), c, t)
                                   for k, c, t in group_totals(rows, lambda r: r["created"][:7])]),
    ]


def build_summary_html(rows, subtitle="") -> str:
    """รายงานสรุปยอด: A4 แนวตั้ง"""
    from html import escape as e
    parts = []
    for title, data in summary_sections(rows):
        body = "".join(f'<tr><td>{e(str(k))}</td><td class="c">{c}</td><td class="r">{fmt_amount(t)}</td></tr>'
                       for k, c, t in data)
        parts.append(f"<h2>{e(title)}</h2><table><thead><tr><th>รายการ</th><th>จำนวนฎีกา</th>"
                     f"<th>จำนวนเงิน (บาท)</th></tr></thead><tbody>{body}</tbody></table>")
    total = sum(r["amount"] for r in rows)
    parts.append(f'<h2>รวมทั้งสิ้น</h2><table><tr><td>ฎีกาทั้งหมด {len(rows)} ฉบับ</td>'
                 f'<td class="r">{fmt_amount(total)} บาท</td></tr></table>')
    return _page("รายงานสรุปทะเบียนการจัดทำฎีกา", subtitle, len(rows), "".join(parts), landscape=False)