"""ตรวจความถูกต้องของข้อมูลในฟอร์มก่อนบันทึก"""
from .formats import TICKS, parse_amount, parse_thai_date


def validate(form: dict) -> dict:
    """ตรวจฟอร์ม -> คืน dict พร้อมบันทึก หรือ raise ValueError(รายการข้อผิดพลาด)"""
    errors, out = [], {}

    def need(key, label):
        v = (form.get(key) or "").strip()
        if not v:
            errors.append(f"กรุณากรอก{label}")
        return v

    out["no"] = need("no", "ที่")
    out["subject"] = need("subject", "ฎีกาเรื่อง")
    out["plan"] = need("plan", "แผนงาน")
    out["task"] = (form.get("task") or "").strip()      # งาน (ไม่บังคับ)
    out["expense_type"] = need("expense_type", "รายจ่าย")
    out["expense_item"] = (form.get("expense_item") or "").strip()   # ประเภทรายจ่าย (ไม่บังคับ)
    out["note"] = (form.get("note") or "").strip()

    dates = {}
    for key, label, required in (
        ("created", "วันที่จัดทำ", True),
        ("handover", "วันที่ผู้ส่งมอบ", False),
        ("receive", "วันที่ผู้รับมอบ", False),
    ):
        try:
            d = parse_thai_date(form.get(key))
            if d is None and required:
                errors.append(f"กรุณากรอก{label}")
            dates[key] = d
        except ValueError as e:
            errors.append(f"{label}: {e}")
    try:
        out["amount"] = parse_amount(form.get("amount"))
    except ValueError as e:
        errors.append(str(e))

    c, h, r = dates.get("created"), dates.get("handover"), dates.get("receive")
    if c and h and h < c:
        errors.append("วันที่ส่งมอบต้องไม่ก่อนวันที่จัดทำ")
    if h and r and r < h:
        errors.append("วันที่รับมอบต้องไม่ก่อนวันที่ส่งมอบ")

    # ผู้ส่งมอบ / ผู้รับมอบ และวันที่ ไม่บังคับกรอก (เว้นว่างได้ทั้งหมด)
    for key, label in (("sender", "ผู้ส่งมอบ"), ("receiver", "ผู้รับมอบ")):
        v = (form.get(key) or "").strip()
        if v not in TICKS:
            errors.append(f"{label}ต้องเลือก ✓ หรือ ✗ (หรือเว้นว่าง)")
        out[key] = v

    if errors:
        raise ValueError("\n".join(errors))
    for key in dates:
        out[key] = dates[key].isoformat() if dates[key] else ""
    return out
