"""หน้าต่างหลักของโปรแกรม"""
import logging
import sqlite3
import sys
from datetime import date, datetime
from pathlib import Path

from .. import paths
from ..database import Database
from ..filters import (ALL, STATUSES, ST_DONE, ST_SENT, ST_WAIT, describe_filters, filter_rows,
                       fiscal_year, parse_filters, status_of)
from ..formats import (TICK_NO, TICK_YES, fmt_amount, fmt_thai_date, parse_thai_date, tick_of)
from ..lists import load_lists
from ..paths import migrate_layout
from ..reports import build_print_html, build_summary_html, export_csv
from ..settings import load_config, setup_logging
from ..validation import validate
from .theme import (C_BORDER, C_CARD, C_DONE, C_MUTED, C_PRIMARY, C_SENT, C_TEXT, C_WAIT,
                    ROW_DONE, ROW_SENT, ROW_WAIT, apply_theme)


def run_gui():
    migrate_layout()
    import tkinter as tk
    import webbrowser
    from tkinter import filedialog, messagebox, ttk

    if sys.platform == "win32":      # ให้ตัวหนังสือคมบนจอ Windows ความละเอียดสูง
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

    cfg = load_config()
    setup_logging(cfg)
    db = Database(paths.BASE_DIR / cfg["files"]["database"],
                  cfg.getint("retry", "times"), cfg.getfloat("retry", "wait_seconds"))
    plans, tasks_of, types, items_of = load_lists(paths.BASE_DIR / cfg.get("files", "lists", fallback="config/lists.txt"))
    backup_dir = paths.BASE_DIR / cfg["files"]["backup_dir"]
    backup_keep = cfg.getint("files", "backup_keep", fallback=30)
    dirty = {"v": False}   # มีการแก้ไขข้อมูลตั้งแต่สำรองครั้งล่าสุดหรือไม่

    root = tk.Tk()
    root.title("ทะเบียนการจัดทำฎีกา")
    family, base = apply_theme(root)
    root.minsize(1100, 700)

    def tidy_date(var):
        """พิมพ์ 4/11/69 แล้วออกจากช่อง -> แปลงเป็น 4 พ.ย. 69 ให้เอง (ถ้ารูปแบบผิดปล่อยไว้ให้ตรวจตอนบันทึก)"""
        try:
            d = parse_thai_date(var.get())
        except ValueError:
            return
        if d:
            var.set(fmt_thai_date(d.isoformat()))

    def card(parent, **kw):
        return tk.Frame(parent, bg=C_CARD, highlightbackground=C_BORDER, highlightcolor=C_BORDER,
                        highlightthickness=1, **kw)

    # ----- ส่วนหัว
    status = tk.StringVar()      # ข้อความแจ้งผลด้านล่าง
    footer = ttk.Label(root, textvariable=status, style="Muted.TLabel")
    footer.pack(side="bottom", fill="x", padx=26, pady=(0, 8))

    head = ttk.Frame(root)
    head.pack(fill="x", padx=24, pady=(14, 8))
    ttk.Label(head, text="ทะเบียนการจัดทำฎีกา", style="H1.TLabel").pack(side="left")
    ttk.Label(head, text="บันทึก ติดตามสถานะ และพิมพ์รายงานฎีกา", style="Muted.TLabel").pack(
        side="left", padx=(14, 0), pady=(10, 0))

    # ----- การ์ดสรุปสถานะ (คลิกเพื่อกรองตามสถานะได้)
    flt = {k: tk.StringVar(value=ALL if k in ("fy", "plan", "expense_type", "status") else "")
           for k in ("fy", "plan", "expense_type", "status", "date_from", "date_to")}
    stat_n = {k: tk.StringVar(value="0") for k in ("all", *STATUSES)}
    stat_amt = {k: tk.StringVar(value="0.00 บาท") for k in ("all", *STATUSES)}
    stat_cards = {}

    def pick_status(key):
        flt["status"].set(ALL if key == "all" else key)
        reload()

    cards_row = ttk.Frame(root)
    cards_row.pack(fill="x", padx=24, pady=(0, 8))
    for i, (key, title, accent) in enumerate((("all", "ฎีกาทั้งหมด", C_PRIMARY), (ST_WAIT, ST_WAIT, C_WAIT),
                                              (ST_SENT, ST_SENT, C_SENT), (ST_DONE, ST_DONE, C_DONE))):
        cards_row.columnconfigure(i, weight=1, uniform="stat")
        f = card(cards_row, cursor="hand2")
        f.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 3 else 6))
        strip = tk.Frame(f, bg=accent, width=5)
        strip.pack(side="left", fill="y")
        body = tk.Frame(f, bg=C_CARD)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=4)
        tk.Label(body, text=title, bg=C_CARD, fg=C_MUTED, font=(family, base - 1)).pack(anchor="w")
        line = tk.Frame(body, bg=C_CARD)
        line.pack(anchor="w", fill="x")
        tk.Label(line, textvariable=stat_n[key], bg=C_CARD, fg=C_TEXT,
                 font=(family, base + 6, "bold")).pack(side="left")
        tk.Label(line, textvariable=stat_amt[key], bg=C_CARD, fg=C_MUTED,
                 font=(family, base - 1)).pack(side="left", padx=(10, 0), pady=(5, 0))

        def bind_all(w, k=key):
            w.bind("<Button-1>", lambda _e: pick_status(k))
            for ch in w.winfo_children():
                bind_all(ch, k)
        bind_all(f)
        stat_cards[key] = f

    # ----- ฟอร์มกรอกข้อมูล
    vars_ = {k: tk.StringVar() for k in
             ("no", "created", "subject", "plan", "task", "expense_type", "expense_item", "amount",
              "sender", "handover", "receiver", "receive", "note")}
    form_card = card(root)
    form_card.pack(fill="x", padx=24, pady=(0, 8))
    form_title = tk.StringVar(value="เพิ่มฎีกาใหม่")
    ttk.Label(form_card, textvariable=form_title, style="H2.TLabel").pack(anchor="w", padx=18, pady=(10, 0))
    form = tk.Frame(form_card, bg=C_CARD)
    form.pack(fill="x", padx=12, pady=(0, 4))
    for c in range(6):
        form.columnconfigure(c, weight=1, uniform="f")

    def field(label, key, r, c, span=1, values=None):
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        w = (ttk.Combobox(form, textvariable=vars_[key], values=values)
             if values is not None else ttk.Entry(form, textvariable=vars_[key], style="App.TEntry"))
        w.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="ew", padx=6)
        if key in ("created", "handover", "receive"):
            w.bind("<FocusOut>", lambda _e, v=vars_[key]: tidy_date(v))
        return w

    def tickfield(label, key, r, c, span=1):
        """เลือก ✓ (ถูก) / ✗ (กากบาท) / ว่าง แทนการพิมพ์ชื่อ"""
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        box = tk.Frame(form, bg=C_CARD)
        box.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="w", padx=6)
        for text, val, sty in (("ว่าง", "", "Blank"), ("✓ ถูก", TICK_YES, "Yes"), ("✗ กากบาท", TICK_NO, "No")):
            ttk.Radiobutton(box, text=text, value=val, variable=vars_[key],
                            style=f"{sty}.Toolbutton").pack(side="left", padx=(0, 4))

    # จัดวางบนตาราง 6 คอลัมน์ (แถวละ 6 ส่วน)
    field("ที่ *", "no", 0, 0)
    field("วันที่จัดทำ * (เช่น 4 พ.ย. 69)", "created", 0, 1)
    subject_entry = field("ฎีกาเรื่อง *", "subject", 0, 2, span=2)
    field("หมายเหตุ", "note", 0, 4, span=2)
    field("แผนงาน *", "plan", 1, 0, span=3, values=plans)
    task_box = field("งาน (เลือกแผนงานก่อน)", "task", 1, 3, span=3, values=[])
    field("รายจ่าย *", "expense_type", 2, 0, span=2, values=types)
    item_box = field("ประเภทรายจ่าย (เลือกรายจ่ายก่อน)", "expense_item", 2, 2, span=3, values=[])
    field("จำนวนเงิน (บาท) *", "amount", 2, 5)
    tickfield("ผู้ส่งมอบ", "sender", 3, 0, span=2)
    field("วันที่ส่งมอบ (เช่น 4 พ.ย. 69)", "handover", 3, 2)
    tickfield("ผู้รับมอบ", "receiver", 3, 3, span=2)
    field("วันที่รับมอบ (เช่น 4 พ.ย. 69)", "receive", 3, 5)

    def link(parent_key, child_key, child_box, mapping):
        """ช่องลูก (งาน / ประเภทรายจ่าย) แสดงเฉพาะตัวเลือกของช่องแม่ที่เลือกอยู่"""
        def on_change(*_):
            opts = mapping.get(vars_[parent_key].get(), [])
            child_box["values"] = opts
            cur = vars_[child_key].get()
            if cur and opts and cur not in opts:
                vars_[child_key].set("")
        vars_[parent_key].trace_add("write", on_change)

    link("plan", "task", task_box, tasks_of)
    link("expense_type", "expense_item", item_box, items_of)

    state = {"id": None}   # id ของรายการที่กำลังแก้ไข (None = เพิ่มใหม่)
    save_label = tk.StringVar(value="บันทึก")
    btns = tk.Frame(form_card, bg=C_CARD)
    btns.pack(fill="x", padx=18, pady=(6, 12))

    # ----- ตารางรายการ + ตัวกรอง
    table_card = card(root)
    table_card.pack(fill="both", expand=True, padx=24, pady=(0, 6))
    search_var = tk.StringVar()

    tools = tk.Frame(table_card, bg=C_CARD)
    tools.pack(fill="x", padx=14, pady=(10, 4))
    ttk.Label(tools, text="รายการฎีกา", style="H2.TLabel").pack(side="left", padx=(0, 16))
    search_entry = ttk.Entry(tools, textvariable=search_var, style="App.TEntry", width=26)
    search_entry.pack(side="left")
    ttk.Button(tools, text="ค้นหา", command=lambda: reload()).pack(side="left", padx=(6, 0))
    ttk.Button(tools, text="ล้างตัวกรอง", command=lambda: clear_filters()).pack(side="left", padx=(6, 0))
    tools_right = tk.Frame(tools, bg=C_CARD)
    tools_right.pack(side="right")

    filters = tk.Frame(table_card, bg=C_CARD)
    filters.pack(fill="x", padx=14, pady=(2, 8))
    combos = {}

    def fcombo(label, key, width):
        ttk.Label(filters, text=label, style="Field.TLabel").pack(side="left", padx=(0, 4))
        c = ttk.Combobox(filters, textvariable=flt[key], width=width, state="readonly")
        c.pack(side="left", padx=(0, 12))
        c.bind("<<ComboboxSelected>>", lambda _: reload())
        combos[key] = c

    def fentry(label, key):
        ttk.Label(filters, text=label, style="Field.TLabel").pack(side="left", padx=(0, 4))
        en = ttk.Entry(filters, textvariable=flt[key], style="App.TEntry", width=11)
        en.pack(side="left", padx=(0, 12))
        en.bind("<Return>", lambda _: reload())
        en.bind("<FocusOut>", lambda _e, v=flt[key]: tidy_date(v))

    fcombo("ปีงบประมาณ", "fy", 8)
    fentry("วันที่จัดทำ ตั้งแต่", "date_from")
    fentry("ถึง", "date_to")
    fcombo("แผนงาน", "plan", 18)
    fcombo("รายจ่าย", "expense_type", 14)
    fcombo("สถานะ", "status", 11)

    def clear_filters():
        for k, v in flt.items():
            v.set(ALL if k in ("fy", "plan", "expense_type", "status") else "")
        search_var.set("")
        reload()

    ttk.Separator(table_card, orient="horizontal").pack(fill="x")

    heads = [("no", "ที่", 52, "w", False), ("created", "วันที่จัดทำ", 100, "w", False),
             ("subject", "ฎีกาเรื่อง", 200, "w", True), ("plan", "แผนงาน", 150, "w", False), ("task", "งาน", 170, "w", False),
             ("expense_type", "รายจ่าย", 115, "w", False), ("expense_item", "ประเภทรายจ่าย", 190, "w", False), ("amount", "จำนวนเงิน", 110, "e", False),
             ("sender", "ผู้ส่งมอบ", 80, "center", False), ("handover", "ส่งมอบ", 90, "center", False),
             ("receiver", "ผู้รับมอบ", 80, "center", False), ("receive", "รับมอบ", 90, "center", False),
             ("status", "สถานะ", 105, "w", False), ("note", "หมายเหตุ", 110, "w", True)]
    tf = tk.Frame(table_card, bg=C_CARD)
    tf.pack(fill="both", expand=True)
    tree = ttk.Treeview(tf, columns=[h[0] for h in heads], show="headings", selectmode="browse")
    for key, text, w, anchor, stretch in heads:
        tree.heading(key, text=text, anchor="e" if anchor == "e" else "w")
        tree.column(key, width=w, minwidth=50, anchor=anchor, stretch=stretch)
    sb = ttk.Scrollbar(tf, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(tf, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=sb.set, xscrollcommand=hsb.set)
    tf.rowconfigure(0, weight=1)
    tf.columnconfigure(0, weight=1)
    tree.grid(row=0, column=0, sticky="nsew")
    sb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    tag_of = {ST_WAIT: "wait", ST_SENT: "sent", ST_DONE: "done"}
    tree.tag_configure("wait", background=ROW_WAIT)
    tree.tag_configure("sent", background=ROW_SENT)
    tree.tag_configure("done", background=ROW_DONE)
    empty = tk.Label(tf, text="ยังไม่มีรายการ", bg=C_CARD, fg=C_MUTED, font=(family, base + 1))

    # ----- การทำงาน
    def current_rows():
        """รายการตามคำค้น + ตัวกรอง ; raise ValueError ถ้าตัวกรองผิดรูปแบบ"""
        f = parse_filters({k: v.get() for k, v in flt.items()})
        return filter_rows(db.search(search_var.get()), f), f

    def refresh_filter_lists():
        rows = db.search("")
        combos["fy"]["values"] = [ALL] + [str(y) for y in sorted({fiscal_year(r["created"]) for r in rows}, reverse=True)]
        combos["plan"]["values"] = [ALL] + sorted(set(plans) | {r["plan"] for r in rows})
        combos["expense_type"]["values"] = [ALL] + sorted(set(types) | {r["expense_type"] for r in rows})
        combos["status"]["values"] = [ALL] + STATUSES

    def reload(_=None):
        try:
            f = parse_filters({k: v.get() for k, v in flt.items()})
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return []
        refresh_filter_lists()
        # การ์ดสรุปนับจากตัวกรองทุกอย่าง "ยกเว้นสถานะ" เพื่อให้เทียบสถานะกันได้
        base_rows = filter_rows(db.search(search_var.get()), {**f, "status": ""})
        rows = [r for r in base_rows if not f["status"] or status_of(r) == f["status"]]
        tree.delete(*tree.get_children())
        for r in rows:
            st = status_of(r)
            tree.insert("", "end", iid=str(r["id"]), tags=(tag_of[st],), values=(
                r["no"], fmt_thai_date(r["created"]), r["subject"], r["plan"], r["task"], r["expense_type"], r["expense_item"],
                fmt_amount(r["amount"]), tick_of(r["sender"]), fmt_thai_date(r["handover"]),
                tick_of(r["receiver"]), fmt_thai_date(r["receive"]), st, r["note"]))
        counts = {s: [0, 0] for s in STATUSES}
        for r in base_rows:
            c = counts[status_of(r)]
            c[0] += 1
            c[1] += r["amount"]
        stat_n["all"].set(f"{len(base_rows)} ฉบับ")
        stat_amt["all"].set(f"{fmt_amount(sum(r['amount'] for r in base_rows))} บาท")
        for s in STATUSES:
            stat_n[s].set(f"{counts[s][0]} ฉบับ")
            stat_amt[s].set(f"{fmt_amount(counts[s][1])} บาท")
        active = f["status"] or "all"
        for key, fr in stat_cards.items():
            fr.configure(highlightbackground=C_PRIMARY if key == active else C_BORDER,
                         highlightthickness=2 if key == active else 1)
        if rows:
            empty.place_forget()
        else:
            empty.configure(text="ไม่พบรายการตามเงื่อนไข" if db.search("") else "ยังไม่มีรายการ — กรอกข้อมูลด้านบนแล้วกด บันทึก")
            empty.place(relx=0.5, rely=0.45, anchor="center")
        status.set(f"แสดง {len(rows)} รายการ   รวมเงิน {fmt_amount(sum(r['amount'] for r in rows))} บาท")
        return rows

    def set_mode(editing_no=None):
        if editing_no is None:
            form_title.set("เพิ่มฎีกาใหม่")
            save_label.set("บันทึก")
        else:
            form_title.set(f"กำลังแก้ไขฎีกา ที่ {editing_no}")
            save_label.set("บันทึกการแก้ไข")

    def clear():
        state["id"] = None
        for v in vars_.values():
            v.set("")
        vars_["no"].set(db.next_no())
        vars_["created"].set(fmt_thai_date(date.today().isoformat()))
        tree.selection_remove(tree.selection())
        set_mode()
        subject_entry.focus_set()

    def on_select(_=None):
        sel = tree.selection()
        if not sel:
            return
        r = db.get(int(sel[0]))
        state["id"] = r["id"]
        for k in vars_:
            val = r[k]
            if k in ("created", "handover", "receive"):
                val = fmt_thai_date(val)
            elif k == "amount":
                val = f"{val / 100:.2f}"
            elif k in ("sender", "receiver"):
                val = tick_of(val)
            vars_[k].set(val)
        set_mode(r["no"])

    def save(_=None):
        try:
            rec = validate({k: v.get() for k, v in vars_.items()})
            if state["id"] is None:
                db.add(rec)
                msg = f"เพิ่มฎีกา ที่ {rec['no']} แล้ว"
            else:
                db.update(state["id"], rec)
                msg = f"แก้ไขฎีกา ที่ {rec['no']} แล้ว"
        except ValueError as ex:
            messagebox.showwarning("ข้อมูลไม่ถูกต้อง", str(ex))
            return
        except sqlite3.Error as ex:
            logging.exception("บันทึกไม่สำเร็จ")
            messagebox.showerror("บันทึกไม่สำเร็จ", f"ฐานข้อมูลมีปัญหา: {ex}\nดูรายละเอียดในไฟล์ log")
            return
        dirty["v"] = True
        reload()
        clear()
        status.set(f"✓ {msg}   |   {status.get()}")

    def delete():
        if state["id"] is None:
            messagebox.showinfo("ลบ", "กรุณาเลือกรายการในตารางก่อน")
            return
        if messagebox.askyesno("ยืนยัน", "ลบรายการนี้ถาวรหรือไม่?"):
            db.delete(state["id"])
            dirty["v"] = True
            reload()
            clear()

    def do_export():
        try:
            rows, _f = current_rows()
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return
        folder = paths.BASE_DIR / cfg["files"]["export_dir"]
        folder.mkdir(exist_ok=True)
        dest = filedialog.asksaveasfilename(
            initialdir=folder, initialfile=f"deeka_{datetime.now():%Y%m%d}.csv",
            defaultextension=".csv", filetypes=[("CSV (เปิดด้วย Excel)", "*.csv")])
        if dest:
            n = export_csv(rows, Path(dest))
            messagebox.showinfo("ส่งออก", f"ส่งออก {n} รายการ (ตามตัวกรองที่เลือก) เรียบร้อย\n{dest}")

    def open_report(builder, filename):
        try:
            rows, f = current_rows()
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return
        if not rows:
            messagebox.showinfo("พิมพ์", "ไม่มีรายการให้พิมพ์")
            return
        folder = paths.BASE_DIR / cfg["files"]["export_dir"]
        folder.mkdir(exist_ok=True)
        dest = folder / filename
        dest.write_text(builder(rows, subtitle=describe_filters(f, search_var.get())), encoding="utf-8")
        logging.info("สร้างรายงาน %s (%s รายการ)", filename, len(rows))
        webbrowser.open(dest.as_uri())   # เปิดเบราว์เซอร์ + หน้าต่างพิมพ์ขึ้นเอง

    def do_backup():
        dest = db.backup(backup_dir, backup_keep)
        dirty["v"] = False
        messagebox.showinfo("สำรองข้อมูล", f"สำรองข้อมูลแล้ว\n{dest}")

    def on_close():
        """สำรองอัตโนมัติตอนปิดโปรแกรม (เฉพาะเมื่อมีการแก้ไขข้อมูล)"""
        if dirty["v"]:
            try:
                db.backup(backup_dir, backup_keep)
            except Exception:
                logging.exception("สำรองอัตโนมัติไม่สำเร็จ")
        try:
            db.conn.close()
        finally:
            root.destroy()

    # ----- ปุ่ม
    ttk.Button(btns, text="ลบรายการ", style="Danger.TButton", command=delete).pack(side="right")
    ttk.Button(btns, text="ล้างฟอร์ม / เพิ่มใหม่", command=clear).pack(side="right", padx=8)
    ttk.Button(btns, textvariable=save_label, style="Primary.TButton", command=save).pack(side="right")
    for text, cmd in (("สำรองข้อมูล", do_backup), ("ส่งออก CSV", do_export),
                      ("รายงานสรุป", lambda: open_report(build_summary_html, "summary_deeka.html")),
                      ("พิมพ์ทะเบียน", lambda: open_report(build_print_html, "print_deeka.html"))):
        ttk.Button(tools_right, text=text, command=cmd).pack(side="right", padx=(6, 0))

    search_entry.bind("<Return>", lambda _: reload())
    tree.bind("<<TreeviewSelect>>", on_select)
    root.bind_all("<Command-s>" if sys.platform == "darwin" else "<Control-s>", save)
    root.protocol("WM_DELETE_WINDOW", on_close)

    reload()
    clear()
    w, h = 1340, min(max(root.winfo_screenheight() - 100, 700), 980)   # สูงตามหน้าจอ เพื่อให้ตารางเห็นหลายแถว
    root.geometry(f"{w}x{h}+{max((root.winfo_screenwidth() - w) // 2, 0)}+{max((root.winfo_screenheight() - h) // 3, 0)}")
    root.mainloop()


if __name__ == "__main__":
    run_gui()
