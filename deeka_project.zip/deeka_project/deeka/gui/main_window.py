"""หน้าต่างหลักของโปรแกรม"""
import logging
import sqlite3
import sys
from datetime import date, datetime
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from .. import paths
from ..database import Database
from ..filters import (ALL, STATUSES, ST_DONE, ST_SENT, ST_WAIT, describe_filters, filter_rows,
                       fiscal_year, parse_filters, status_of)
from ..formats import (TICK_NO, TICK_YES, fmt_amount, fmt_thai_date, parse_thai_date, tick_of)
from ..lists import load_lists
from ..paths import migrate_layout
from ..reports import build_print_html, build_summary_html, export_csv
from ..settings import load_config, setup_logging
from ..validation import validate
from .theme import (C_BORDER, C_CARD, C_DONE, C_MUTED, C_PRIMARY, C_SENT, C_TEXT, C_WAIT,
                    ROW_DONE, ROW_SENT, ROW_WAIT, apply_theme)



_LISTS_HEADER = """# รายการ แผนงาน / งาน / รายจ่าย / ประเภทรายจ่าย ที่ใช้เลือกในโปรแกรม (แก้ไขด้วย Notepad แล้วเปิดโปรแกรมใหม่)
# บรรทัดที่ไม่ขึ้นต้นด้วย - คือ "แผนงาน" (หรือ "รายจ่าย" ในส่วน [รายจ่าย])
# บรรทัดที่ขึ้นต้นด้วย - คือ "งาน" (หรือ "ประเภทรายจ่าย") ของบรรทัดหลักที่อยู่ด้านบน
# บรรทัดที่ขึ้นต้นด้วย # คือหมายเหตุ (โปรแกรมไม่อ่าน)"""


def save_lists(path, plans, tasks_of, types, items_of):
    """เขียนรายการกลับลง lists.txt (เขียนไฟล์ชั่วคราวก่อนแล้วสลับ กันไฟล์เสีย)"""
    out = [_LISTS_HEADER]
    for p in plans:
        out.append(p)
        out += ["-" + t for t in tasks_of.get(p, [])]
    out += ["", "[รายจ่าย]"]
    for t in types:
        out.append(t)
        out += ["-" + i for i in items_of.get(t, [])]
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text("\n".join(out) + "\n", encoding="utf-8")
    tmp.replace(path)

class _Panel:
    """แผงเดียว: ซ้าย = รายการหลัก, ขวา = รายการย่อยของรายการหลักที่เลือก"""

    def __init__(self, parent, parents, kids_of, parent_title, kid_title, on_change):
        self.parents, self.kids_of, self.on_change = parents, kids_of, on_change
        self.frame = tk.Frame(parent, bg=C_CARD)
        self.frame.columnconfigure((0, 1), weight=1, uniform="p")
        self.frame.rowconfigure(1, weight=1)
        self.pbox = self._column(0, parent_title, self.add_parent, self.rename_parent, self.del_parent)
        self.kbox = self._column(1, kid_title, self.add_kid, self.rename_kid, self.del_kid)
        self.pbox.bind("<<ListboxSelect>>", lambda _e: self.show_kids())
        self.refresh()

    def _column(self, col, title, add, rename, delete):
        ttk.Label(self.frame, text=title, style="H2.TLabel").grid(row=0, column=col, sticky="w", padx=8, pady=(8, 4))
        holder = tk.Frame(self.frame, bg=C_CARD)
        holder.grid(row=1, column=col, sticky="nsew", padx=8)
        box = tk.Listbox(holder, exportselection=False, activestyle="none", height=14)
        sb = ttk.Scrollbar(holder, orient="vertical", command=box.yview)
        box.configure(yscrollcommand=sb.set)
        box.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        var = tk.StringVar()
        ent = ttk.Entry(self.frame, textvariable=var)
        ent.grid(row=2, column=col, sticky="ew", padx=8, pady=(6, 2))
        ent.bind("<Return>", lambda _e: add())
        bar = tk.Frame(self.frame, bg=C_CARD)
        bar.grid(row=3, column=col, sticky="w", padx=8, pady=(0, 8))
        ttk.Button(bar, text="เพิ่ม", command=add).pack(side="left")
        ttk.Button(bar, text="เปลี่ยนชื่อ", command=rename).pack(side="left", padx=4)
        ttk.Button(bar, text="ลบ", command=delete).pack(side="left")
        box.entry = var
        box.bind("<<ListboxSelect>>", lambda _e, b=box: self._fill(b), add="+")
        return box

    def _fill(self, box):
        sel = box.curselection()
        if sel:
            box.entry.set(box.get(sel[0]))

    def cur_parent(self):
        sel = self.pbox.curselection()
        return self.pbox.get(sel[0]) if sel else None

    def cur_kid(self):
        sel = self.kbox.curselection()
        return self.kbox.get(sel[0]) if sel else None

    def refresh(self, keep=None):
        self.pbox.delete(0, "end")
        for p in self.parents:
            self.pbox.insert("end", p)
        if keep in self.parents:
            i = self.parents.index(keep)
            self.pbox.selection_set(i)
            self.pbox.see(i)
        self.show_kids()

    def show_kids(self, keep=None):
        self.kbox.delete(0, "end")
        p = self.cur_parent()
        for k in self.kids_of.get(p, []):
            self.kbox.insert("end", k)
        if keep in self.kids_of.get(p, []):
            i = self.kids_of[p].index(keep)
            self.kbox.selection_set(i)
            self.kbox.see(i)

    # ---- รายการหลัก ----
    def add_parent(self):
        name = " ".join(self.pbox.entry.get().split())
        if not name:
            return
        if name in self.parents:
            messagebox.showinfo("มีอยู่แล้ว", f"“{name}” มีอยู่ในรายการแล้ว")
            return
        self.parents.append(name)
        self.kids_of.setdefault(name, [])
        self.on_change()
        self.refresh(name)

    def rename_parent(self):
        old, new = self.cur_parent(), " ".join(self.pbox.entry.get().split())
        if not old or not new or new == old:
            return
        if new in self.parents:
            messagebox.showinfo("มีอยู่แล้ว", f"“{new}” มีอยู่ในรายการแล้ว")
            return
        self.parents[self.parents.index(old)] = new
        self.kids_of[new] = self.kids_of.pop(old, [])
        self.on_change()
        self.refresh(new)

    def del_parent(self):
        old = self.cur_parent()
        if not old:
            messagebox.showinfo("ลบ", "กรุณาเลือกรายการทางซ้ายก่อน")
            return
        n = len(self.kids_of.get(old, []))
        if messagebox.askyesno("ยืนยัน", f"ลบ “{old}”" + (f" และรายการย่อยอีก {n} รายการ" if n else "") +
                               "?\n(ข้อมูลฎีกาที่บันทึกไว้แล้วไม่ถูกลบ)"):
            self.parents.remove(old)
            self.kids_of.pop(old, None)
            self.on_change()
            self.refresh()

    # ---- รายการย่อย ----
    def add_kid(self):
        p = self.cur_parent()
        name = " ".join(self.kbox.entry.get().split())
        if not p:
            messagebox.showinfo("เพิ่ม", "กรุณาเลือกรายการทางซ้ายก่อน")
            return
        if not name:
            return
        if name in self.kids_of.setdefault(p, []):
            messagebox.showinfo("มีอยู่แล้ว", f"“{name}” มีอยู่ใน “{p}” แล้ว")
            return
        self.kids_of[p].append(name)
        self.on_change()
        self.show_kids(name)

    def rename_kid(self):
        p, old, new = self.cur_parent(), self.cur_kid(), " ".join(self.kbox.entry.get().split())
        if not p or not old or not new or new == old:
            return
        if new in self.kids_of[p]:
            messagebox.showinfo("มีอยู่แล้ว", f"“{new}” มีอยู่ใน “{p}” แล้ว")
            return
        self.kids_of[p][self.kids_of[p].index(old)] = new
        self.on_change()
        self.show_kids(new)

    def del_kid(self):
        p, old = self.cur_parent(), self.cur_kid()
        if not p or not old:
            messagebox.showinfo("ลบ", "กรุณาเลือกรายการทางขวาก่อน")
            return
        if messagebox.askyesno("ยืนยัน", f"ลบ “{old}” ออกจาก “{p}”?\n(ข้อมูลฎีกาที่บันทึกไว้แล้วไม่ถูกลบ)"):
            self.kids_of[p].remove(old)
            self.on_change()
            self.show_kids()


def open_manager(root, plans, tasks_of, types, items_of, on_change):
    """เปิดหน้าต่างจัดการรายการ; on_change() ถูกเรียกทุกครั้งที่มีการเพิ่ม/แก้/ลบ (ให้บันทึกไฟล์และรีเฟรชช่องเลือก)"""
    win = tk.Toplevel(root)
    win.title("จัดการรายการตัวเลือก")
    win.geometry("860x560")
    win.transient(root)
    nb = ttk.Notebook(win)
    nb.pack(fill="both", expand=True, padx=12, pady=(12, 4))
    p1 = _Panel(nb, plans, tasks_of, "แผนงาน", "งาน (ของแผนงานที่เลือก)", on_change)
    p2 = _Panel(nb, types, items_of, "รายจ่าย", "ประเภทรายจ่าย (ของรายจ่ายที่เลือก)", on_change)
    nb.add(p1.frame, text="  แผนงาน / งาน  ")
    nb.add(p2.frame, text="  รายจ่าย / ประเภทรายจ่าย  ")
    ttk.Label(win, text="เลือกรายการ → พิมพ์ชื่อในช่อง → กด เพิ่ม / เปลี่ยนชื่อ   (บันทึกลงไฟล์ให้อัตโนมัติ  ข้อมูลฎีกาเดิมไม่เปลี่ยน)",
              style="Field.TLabel").pack(anchor="w", padx=14, pady=(0, 4))
    ttk.Button(win, text="ปิด", command=win.destroy).pack(anchor="e", padx=14, pady=(0, 12))
    win.grab_set()
    return win


def run_gui():
    migrate_layout()
    import tkinter as tk
    import webbrowser
    from tkinter import filedialog, messagebox, ttk

    if sys.platform == "win32":      # ให้ตัวหนังสือคมบนจอ Windows ความละเอียดสูง
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

    cfg = load_config()
    setup_logging(cfg)
    db = Database(paths.BASE_DIR / cfg["files"]["database"],
                  cfg.getint("retry", "times"), cfg.getfloat("retry", "wait_seconds"))
    lists_path = paths.BASE_DIR / cfg.get("files", "lists", fallback="config/lists.txt")
    plans, tasks_of, types, items_of = load_lists(lists_path)
    backup_dir = paths.BASE_DIR / cfg["files"]["backup_dir"]
    backup_keep = cfg.getint("files", "backup_keep", fallback=30)
    dirty = {"v": False}   # มีการแก้ไขข้อมูลตั้งแต่สำรองครั้งล่าสุดหรือไม่

    root = tk.Tk()
    root.title("ทะเบียนการจัดทำฎีกา")
    family, base = apply_theme(root)
    root.minsize(1100, 700)

    def tidy_date(var):
        """พิมพ์ 4/11/69 แล้วออกจากช่อง -> แปลงเป็น 4 พ.ย. 69 ให้เอง (ถ้ารูปแบบผิดปล่อยไว้ให้ตรวจตอนบันทึก)"""
        try:
            d = parse_thai_date(var.get())
        except ValueError:
            return
        if d:
            var.set(fmt_thai_date(d.isoformat()))

    def card(parent, **kw):
        return tk.Frame(parent, bg=C_CARD, highlightbackground=C_BORDER, highlightcolor=C_BORDER,
                        highlightthickness=1, **kw)

    # ----- ส่วนหัว
    status = tk.StringVar()      # ข้อความแจ้งผลด้านล่าง
    footer = ttk.Label(root, textvariable=status, style="Muted.TLabel")
    footer.pack(side="bottom", fill="x", padx=26, pady=(0, 8))

    head = ttk.Frame(root)
    head.pack(fill="x", padx=24, pady=(14, 8))
    ttk.Label(head, text="ทะเบียนการจัดทำฎีกา", style="H1.TLabel").pack(side="left")
    ttk.Label(head, text="บันทึก ติดตามสถานะ และพิมพ์รายงานฎีกา", style="Muted.TLabel").pack(
        side="left", padx=(14, 0), pady=(10, 0))

    # ----- การ์ดสรุปสถานะ (คลิกเพื่อกรองตามสถานะได้)
    flt = {k: tk.StringVar(value=ALL if k in ("fy", "plan", "expense_type", "status") else "")
           for k in ("fy", "plan", "expense_type", "status", "date_from", "date_to")}
    stat_n = {k: tk.StringVar(value="0") for k in ("all", *STATUSES)}
    stat_amt = {k: tk.StringVar(value="0.00 บาท") for k in ("all", *STATUSES)}
    stat_cards = {}

    def pick_status(key):
        flt["status"].set(ALL if key == "all" else key)
        reload()

    cards_row = ttk.Frame(root)
    cards_row.pack(fill="x", padx=24, pady=(0, 8))
    for i, (key, title, accent) in enumerate((("all", "ฎีกาทั้งหมด", C_PRIMARY), (ST_WAIT, ST_WAIT, C_WAIT),
                                              (ST_SENT, ST_SENT, C_SENT), (ST_DONE, ST_DONE, C_DONE))):
        cards_row.columnconfigure(i, weight=1, uniform="stat")
        f = card(cards_row, cursor="hand2")
        f.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 3 else 6))
        strip = tk.Frame(f, bg=accent, width=5)
        strip.pack(side="left", fill="y")
        body = tk.Frame(f, bg=C_CARD)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=4)
        tk.Label(body, text=title, bg=C_CARD, fg=C_MUTED, font=(family, base - 1)).pack(anchor="w")
        line = tk.Frame(body, bg=C_CARD)
        line.pack(anchor="w", fill="x")
        tk.Label(line, textvariable=stat_n[key], bg=C_CARD, fg=C_TEXT,
                 font=(family, base + 6, "bold")).pack(side="left")
        tk.Label(line, textvariable=stat_amt[key], bg=C_CARD, fg=C_MUTED,
                 font=(family, base - 1)).pack(side="left", padx=(10, 0), pady=(5, 0))

        def bind_all(w, k=key):
            w.bind("<Button-1>", lambda _e: pick_status(k))
            for ch in w.winfo_children():
                bind_all(ch, k)
        bind_all(f)
        stat_cards[key] = f

    # ----- ฟอร์มกรอกข้อมูล
    vars_ = {k: tk.StringVar() for k in
             ("no", "created", "subject", "plan", "task", "expense_type", "expense_item", "amount",
              "sender", "handover", "receiver", "receive", "note")}
    form_card = card(root)
    form_card.pack(fill="x", padx=24, pady=(0, 8))
    form_title = tk.StringVar(value="เพิ่มฎีกาใหม่")
    ttk.Label(form_card, textvariable=form_title, style="H2.TLabel").pack(anchor="w", padx=18, pady=(10, 0))
    form = tk.Frame(form_card, bg=C_CARD)
    form.pack(fill="x", padx=12, pady=(0, 4))
    for c in range(6):
        form.columnconfigure(c, weight=1, uniform="f")

    def field(label, key, r, c, span=1, values=None):
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        w = (ttk.Combobox(form, textvariable=vars_[key], values=values)
             if values is not None else ttk.Entry(form, textvariable=vars_[key], style="App.TEntry"))
        w.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="new", padx=6)
        if key in ("created", "handover", "receive"):
            w.bind("<FocusOut>", lambda _e, v=vars_[key]: tidy_date(v))
        return w

    def subject_field(label, key, r, c, span=1, min_lines=2, max_lines=6):
        """ช่องข้อความหลายบรรทัด: เรื่องยาวจะขึ้นบรรทัดใหม่เองและขยายความสูงตั้งแต่ 2 ถึง 6 บรรทัด
        (ค่าที่เก็บเป็นข้อความบรรทัดเดียว ไม่มีการขึ้นบรรทัดจริง จึงไม่กระทบการค้นหา/พิมพ์)"""
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        var = vars_[key]
        box = tk.Text(form, height=min_lines, wrap="word", font="TkDefaultFont", relief="flat", bd=0,
                      padx=8, pady=6, undo=True, highlightthickness=1, highlightbackground="#CBD5E1",
                      highlightcolor=C_PRIMARY, bg=C_CARD, fg=C_TEXT, insertbackground=C_TEXT)
        box.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="ew", padx=6)

        def text_value():
            return " ".join(box.get("1.0", "end-1c").split())

        def resize(_e=None):
            try:
                n = box.count("1.0", "end-1c", "displaylines")
                n = n[0] if n else 1
            except tk.TclError:
                n = min_lines
            box.configure(height=max(min_lines, min(max_lines, n)))

        def typed(_e=None):
            if text_value() != " ".join(var.get().split()):
                var.set(text_value())
            resize()

        def from_var(*_):                         # เมื่อโปรแกรมตั้งค่า (เลือกแถว/ล้างฟอร์ม) -> อัปเดตกล่อง
            if text_value() != " ".join(var.get().split()):
                box.delete("1.0", "end")
                box.insert("1.0", var.get())
            resize()

        var.trace_add("write", from_var)
        box.bind("<KeyRelease>", typed)
        box.bind("<<Paste>>", lambda _e: box.after(10, typed))
        box.bind("<Configure>", resize)
        box.bind("<Return>", lambda _e: "break")                   # ไม่ให้ขึ้นบรรทัดใหม่ด้วยการกด Enter
        box.bind("<Tab>", lambda _e: (box.tk_focusNext().focus_set(), "break")[1])
        box.bind("<Shift-Tab>", lambda _e: (box.tk_focusPrev().focus_set(), "break")[1])
        return box

    def tickfield(label, key, r, c, span=1):
        """เลือก ✓ (ถูก) / ✗ (กากบาท) / ว่าง แทนการพิมพ์ชื่อ"""
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        box = tk.Frame(form, bg=C_CARD)
        box.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="w", padx=6)
        for text, val, sty in (("ว่าง", "", "Blank"), ("✓ ถูก", TICK_YES, "Yes"), ("✗ กากบาท", TICK_NO, "No")):
            ttk.Radiobutton(box, text=text, value=val, variable=vars_[key],
                            style=f"{sty}.Toolbutton").pack(side="left", padx=(0, 4))

    # จัดวางบนตาราง 6 คอลัมน์ (แถวละ 6 ส่วน)
    field("ที่ *", "no", 0, 0)
    field("วันที่จัดทำ * (4 พ.ย. 69)", "created", 0, 1)
    subject_entry = subject_field("ฎีกาเรื่อง * (ยาวได้ 2-6 บรรทัด)", "subject", 0, 2, span=2)
    field("หมายเหตุ", "note", 0, 4, span=2)
    plan_box = field("แผนงาน *", "plan", 1, 0, span=3, values=plans)
    task_box = field("งาน (เลือกแผนงานก่อน)", "task", 1, 3, span=3, values=[])
    type_box = field("รายจ่าย *", "expense_type", 2, 0, span=2, values=types)
    item_box = field("ประเภทรายจ่าย (เลือกรายจ่ายก่อน)", "expense_item", 2, 2, span=3, values=[])
    field("จำนวนเงิน (บาท) *", "amount", 2, 5)
    tickfield("ผู้ส่งมอบ", "sender", 3, 0, span=2)
    field("วันที่ส่งมอบ (4 พ.ย. 69)", "handover", 3, 2)
    tickfield("ผู้รับมอบ", "receiver", 3, 3, span=2)
    field("วันที่รับมอบ (4 พ.ย. 69)", "receive", 3, 5)

    def link(parent_key, child_key, child_box, mapping):
        """ช่องลูก (งาน / ประเภทรายจ่าย) แสดงเฉพาะตัวเลือกของช่องแม่ที่เลือกอยู่"""
        def on_change(*_):
            opts = mapping.get(vars_[parent_key].get(), [])
            child_box["values"] = opts
            cur = vars_[child_key].get()
            if cur and opts and cur not in opts:
                vars_[child_key].set("")
        vars_[parent_key].trace_add("write", on_change)

    link("plan", "task", task_box, tasks_of)
    link("expense_type", "expense_item", item_box, items_of)

    def lists_changed():
        """บันทึกรายการลง lists.txt แล้วรีเฟรชช่องเลือกในฟอร์ม"""
        try:
            save_lists(lists_path, plans, tasks_of, types, items_of)
        except OSError as ex:
            logging.exception("บันทึก lists.txt ไม่สำเร็จ")
            messagebox.showerror("บันทึกรายการไม่สำเร็จ", f"เขียนไฟล์ {lists_path.name} ไม่ได้: {ex}")
        plan_box["values"] = plans
        type_box["values"] = types
        task_box["values"] = tasks_of.get(vars_["plan"].get(), [])
        item_box["values"] = items_of.get(vars_["expense_type"].get(), [])

    def learn_new(rec):
        """ถ้าแผนงาน/งาน/รายจ่าย/ประเภทรายจ่ายที่พิมพ์เป็นค่าใหม่ -> ถามว่าจะเพิ่มลงรายการถาวรเลยหรือไม่"""
        new = []
        for parent, kid, plist, kmap, label in (
                (rec["plan"], rec.get("task", ""), plans, tasks_of, ("แผนงาน", "งาน")),
                (rec["expense_type"], rec.get("expense_item", ""), types, items_of, ("รายจ่าย", "ประเภทรายจ่าย"))):
            if parent and parent not in plist:
                new.append(f"{label[0]}: {parent}")
            if kid and kid not in kmap.get(parent, []):
                new.append(f"{label[1]}: {kid}")
        if not new:
            return
        if messagebox.askyesno("พบรายการใหม่", "ค่าต่อไปนี้ยังไม่มีในรายการตัวเลือก\n\n  " + "\n  ".join(new) +
                               "\n\nเพิ่มลงรายการตัวเลือกให้เลือกใช้ครั้งต่อไปเลยหรือไม่?"):
            for parent, kid, plist, kmap in ((rec["plan"], rec.get("task", ""), plans, tasks_of),
                                             (rec["expense_type"], rec.get("expense_item", ""), types, items_of)):
                if parent and parent not in plist:
                    plist.append(parent)
                    kmap.setdefault(parent, [])
                if parent and kid and kid not in kmap[parent]:
                    kmap[parent].append(kid)
            lists_changed()

    state = {"id": None}   # id ของรายการที่กำลังแก้ไข (None = เพิ่มใหม่)
    save_label = tk.StringVar(value="บันทึก")
    btns = tk.Frame(form_card, bg=C_CARD)
    btns.pack(fill="x", padx=18, pady=(6, 12))

    # ----- ตารางรายการ + ตัวกรอง
    table_card = card(root)
    table_card.pack(fill="both", expand=True, padx=24, pady=(0, 6))
    search_var = tk.StringVar()

    tools = tk.Frame(table_card, bg=C_CARD)
    tools.pack(fill="x", padx=14, pady=(10, 4))
    ttk.Label(tools, text="รายการฎีกา", style="H2.TLabel").pack(side="left", padx=(0, 16))
    search_entry = ttk.Entry(tools, textvariable=search_var, style="App.TEntry", width=26)
    search_entry.pack(side="left")
    ttk.Button(tools, text="ค้นหา", command=lambda: reload()).pack(side="left", padx=(6, 0))
    ttk.Button(tools, text="ล้างตัวกรอง", command=lambda: clear_filters()).pack(side="left", padx=(6, 0))
    tools_right = tk.Frame(tools, bg=C_CARD)
    tools_right.pack(side="right")

    filters = tk.Frame(table_card, bg=C_CARD)
    filters.pack(fill="x", padx=14, pady=(2, 8))
    combos = {}

    def fcombo(label, key, width):
        ttk.Label(filters, text=label, style="Field.TLabel").pack(side="left", padx=(0, 4))
        c = ttk.Combobox(filters, textvariable=flt[key], width=width, state="readonly")
        c.pack(side="left", padx=(0, 12))
        c.bind("<<ComboboxSelected>>", lambda _: reload())
        combos[key] = c

    def fentry(label, key):
        ttk.Label(filters, text=label, style="Field.TLabel").pack(side="left", padx=(0, 4))
        en = ttk.Entry(filters, textvariable=flt[key], style="App.TEntry", width=11)
        en.pack(side="left", padx=(0, 12))
        en.bind("<Return>", lambda _: reload())
        en.bind("<FocusOut>", lambda _e, v=flt[key]: tidy_date(v))

    fcombo("ปีงบประมาณ", "fy", 8)
    fentry("วันที่จัดทำ ตั้งแต่", "date_from")
    fentry("ถึง", "date_to")
    fcombo("แผนงาน", "plan", 18)
    fcombo("รายจ่าย", "expense_type", 14)
    fcombo("สถานะ", "status", 11)

    def clear_filters():
        for k, v in flt.items():
            v.set(ALL if k in ("fy", "plan", "expense_type", "status") else "")
        search_var.set("")
        reload()

    ttk.Separator(table_card, orient="horizontal").pack(fill="x")

    heads = [("no", "ที่", 52, "w", False), ("created", "วันที่จัดทำ", 100, "w", False),
             ("subject", "ฎีกาเรื่อง", 200, "w", True), ("plan", "แผนงาน", 150, "w", False), ("task", "งาน", 170, "w", False),
             ("expense_type", "รายจ่าย", 115, "w", False), ("expense_item", "ประเภทรายจ่าย", 190, "w", False), ("amount", "จำนวนเงิน", 110, "e", False),
             ("sender", "ผู้ส่งมอบ", 80, "center", False), ("handover", "ส่งมอบ", 90, "center", False),
             ("receiver", "ผู้รับมอบ", 80, "center", False), ("receive", "รับมอบ", 90, "center", False),
             ("status", "สถานะ", 105, "w", False), ("note", "หมายเหตุ", 110, "w", True)]
    tf = tk.Frame(table_card, bg=C_CARD)
    tf.pack(fill="both", expand=True)
    tree = ttk.Treeview(tf, columns=[h[0] for h in heads], show="headings", selectmode="browse")
    for key, text, w, anchor, stretch in heads:
        tree.heading(key, text=text, anchor="e" if anchor == "e" else "w")
        tree.column(key, width=w, minwidth=50, anchor=anchor, stretch=stretch)
    sb = ttk.Scrollbar(tf, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(tf, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=sb.set, xscrollcommand=hsb.set)
    tf.rowconfigure(0, weight=1)
    tf.columnconfigure(0, weight=1)
    tree.grid(row=0, column=0, sticky="nsew")
    sb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    tag_of = {ST_WAIT: "wait", ST_SENT: "sent", ST_DONE: "done"}
    tree.tag_configure("wait", background=ROW_WAIT)
    tree.tag_configure("sent", background=ROW_SENT)
    tree.tag_configure("done", background=ROW_DONE)
    empty = tk.Label(tf, text="ยังไม่มีรายการ", bg=C_CARD, fg=C_MUTED, font=(family, base + 1))

    # ----- การทำงาน
    def current_rows():
        """รายการตามคำค้น + ตัวกรอง ; raise ValueError ถ้าตัวกรองผิดรูปแบบ"""
        f = parse_filters({k: v.get() for k, v in flt.items()})
        return filter_rows(db.search(search_var.get()), f), f

    def refresh_filter_lists():
        rows = db.search("")
        combos["fy"]["values"] = [ALL] + [str(y) for y in sorted({fiscal_year(r["created"]) for r in rows}, reverse=True)]
        combos["plan"]["values"] = [ALL] + sorted(set(plans) | {r["plan"] for r in rows})
        combos["expense_type"]["values"] = [ALL] + sorted(set(types) | {r["expense_type"] for r in rows})
        combos["status"]["values"] = [ALL] + STATUSES

    def reload(_=None):
        try:
            f = parse_filters({k: v.get() for k, v in flt.items()})
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return []
        refresh_filter_lists()
        # การ์ดสรุปนับจากตัวกรองทุกอย่าง "ยกเว้นสถานะ" เพื่อให้เทียบสถานะกันได้
        base_rows = filter_rows(db.search(search_var.get()), {**f, "status": ""})
        rows = [r for r in base_rows if not f["status"] or status_of(r) == f["status"]]
        tree.delete(*tree.get_children())
        for r in rows:
            st = status_of(r)
            tree.insert("", "end", iid=str(r["id"]), tags=(tag_of[st],), values=(
                r["no"], fmt_thai_date(r["created"]), r["subject"], r["plan"], r["task"], r["expense_type"], r["expense_item"],
                fmt_amount(r["amount"]), tick_of(r["sender"]), fmt_thai_date(r["handover"]),
                tick_of(r["receiver"]), fmt_thai_date(r["receive"]), st, r["note"]))
        counts = {s: [0, 0] for s in STATUSES}
        for r in base_rows:
            c = counts[status_of(r)]
            c[0] += 1
            c[1] += r["amount"]
        stat_n["all"].set(f"{len(base_rows)} ฉบับ")
        stat_amt["all"].set(f"{fmt_amount(sum(r['amount'] for r in base_rows))} บาท")
        for s in STATUSES:
            stat_n[s].set(f"{counts[s][0]} ฉบับ")
            stat_amt[s].set(f"{fmt_amount(counts[s][1])} บาท")
        active = f["status"] or "all"
        for key, fr in stat_cards.items():
            fr.configure(highlightbackground=C_PRIMARY if key == active else C_BORDER,
                         highlightthickness=2 if key == active else 1)
        if rows:
            empty.place_forget()
        else:
            empty.configure(text="ไม่พบรายการตามเงื่อนไข" if db.search("") else "ยังไม่มีรายการ — กรอกข้อมูลด้านบนแล้วกด บันทึก")
            empty.place(relx=0.5, rely=0.45, anchor="center")
        status.set(f"แสดง {len(rows)} รายการ   รวมเงิน {fmt_amount(sum(r['amount'] for r in rows))} บาท")
        return rows

    def set_mode(editing_no=None):
        if editing_no is None:
            form_title.set("เพิ่มฎีกาใหม่")
            save_label.set("บันทึก")
        else:
            form_title.set(f"กำลังแก้ไขฎีกา ที่ {editing_no}")
            save_label.set("บันทึกการแก้ไข")

    def clear():
        state["id"] = None
        for v in vars_.values():
            v.set("")
        vars_["no"].set(db.next_no())
        vars_["created"].set(fmt_thai_date(date.today().isoformat()))
        tree.selection_remove(tree.selection())
        set_mode()
        subject_entry.focus_set()

    def on_select(_=None):
        sel = tree.selection()
        if not sel:
            return
        r = db.get(int(sel[0]))
        state["id"] = r["id"]
        for k in vars_:
            val = r[k]
            if k in ("created", "handover", "receive"):
                val = fmt_thai_date(val)
            elif k == "amount":
                val = f"{val / 100:.2f}"
            elif k in ("sender", "receiver"):
                val = tick_of(val)
            vars_[k].set(val)
        set_mode(r["no"])

    def save(_=None):
        try:
            rec = validate({k: v.get() for k, v in vars_.items()})
            learn_new(rec)
            if state["id"] is None:
                db.add(rec)
                msg = f"เพิ่มฎีกา ที่ {rec['no']} แล้ว"
            else:
                db.update(state["id"], rec)
                msg = f"แก้ไขฎีกา ที่ {rec['no']} แล้ว"
        except ValueError as ex:
            messagebox.showwarning("ข้อมูลไม่ถูกต้อง", str(ex))
            return
        except sqlite3.Error as ex:
            logging.exception("บันทึกไม่สำเร็จ")
            messagebox.showerror("บันทึกไม่สำเร็จ", f"ฐานข้อมูลมีปัญหา: {ex}\nดูรายละเอียดในไฟล์ log")
            return
        dirty["v"] = True
        reload()
        clear()
        status.set(f"✓ {msg}   |   {status.get()}")

    def delete():
        if state["id"] is None:
            messagebox.showinfo("ลบ", "กรุณาเลือกรายการในตารางก่อน")
            return
        if messagebox.askyesno("ยืนยัน", "ลบรายการนี้ถาวรหรือไม่?"):
            db.delete(state["id"])
            dirty["v"] = True
            reload()
            clear()

    def do_export():
        try:
            rows, _f = current_rows()
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return
        folder = paths.BASE_DIR / cfg["files"]["export_dir"]
        folder.mkdir(exist_ok=True)
        dest = filedialog.asksaveasfilename(
            initialdir=folder, initialfile=f"deeka_{datetime.now():%Y%m%d}.csv",
            defaultextension=".csv", filetypes=[("CSV (เปิดด้วย Excel)", "*.csv")])
        if dest:
            n = export_csv(rows, Path(dest))
            messagebox.showinfo("ส่งออก", f"ส่งออก {n} รายการ (ตามตัวกรองที่เลือก) เรียบร้อย\n{dest}")

    def open_report(builder, filename):
        try:
            rows, f = current_rows()
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return
        if not rows:
            messagebox.showinfo("พิมพ์", "ไม่มีรายการให้พิมพ์")
            return
        folder = paths.BASE_DIR / cfg["files"]["export_dir"]
        folder.mkdir(exist_ok=True)
        dest = folder / filename
        dest.write_text(builder(rows, subtitle=describe_filters(f, search_var.get())), encoding="utf-8")
        logging.info("สร้างรายงาน %s (%s รายการ)", filename, len(rows))
        webbrowser.open(dest.as_uri())   # เปิดเบราว์เซอร์ + หน้าต่างพิมพ์ขึ้นเอง

    def do_backup():
        dest = db.backup(backup_dir, backup_keep)
        dirty["v"] = False
        messagebox.showinfo("สำรองข้อมูล", f"สำรองข้อมูลแล้ว\n{dest}")

    def on_close():
        """สำรองอัตโนมัติตอนปิดโปรแกรม (เฉพาะเมื่อมีการแก้ไขข้อมูล)"""
        if dirty["v"]:
            try:
                db.backup(backup_dir, backup_keep)
            except Exception:
                logging.exception("สำรองอัตโนมัติไม่สำเร็จ")
        try:
            db.conn.close()
        finally:
            root.destroy()

    # ----- ปุ่ม
    ttk.Button(btns, text="ลบรายการ", style="Danger.TButton", command=delete).pack(side="right")
    ttk.Button(btns, text="ล้างฟอร์ม / เพิ่มใหม่", command=clear).pack(side="right", padx=8)
    ttk.Button(btns, textvariable=save_label, style="Primary.TButton", command=save).pack(side="right")
    for text, cmd in (("จัดการรายการ", lambda: open_manager(root, plans, tasks_of, types, items_of, lists_changed)),
                      ("สำรองข้อมูล", do_backup), ("ส่งออก CSV", do_export),
                      ("รายงานสรุป", lambda: open_report(build_summary_html, "summary_deeka.html")),
                      ("พิมพ์ทะเบียน", lambda: open_report(build_print_html, "print_deeka.html"))):
        ttk.Button(tools_right, text=text, command=cmd).pack(side="right", padx=(6, 0))

    search_entry.bind("<Return>", lambda _: reload())
    tree.bind("<<TreeviewSelect>>", on_select)

    tip = {"win": None, "after": None, "key": None}

    def hide_tip(_e=None):
        if tip["after"]:
            tree.after_cancel(tip["after"])
            tip["after"] = None
        if tip["win"]:
            tip["win"].destroy()
            tip["win"] = None
        tip["key"] = None

    def show_tip(text, x, y):
        w = tk.Toplevel(tree)
        w.wm_overrideredirect(True)
        w.wm_geometry(f"+{x + 14}+{y + 18}")
        tk.Label(w, text=text, justify="left", wraplength=520, bg="#0F172A", fg="#FFFFFF",
                 padx=10, pady=6, font="TkDefaultFont").pack()
        tip["win"] = w

    def on_motion(e):
        row, col = tree.identify_row(e.y), tree.identify_column(e.x)
        key = (row, col)
        if key == tip["key"]:
            return
        hide_tip()
        if not row or not col:
            return
        text = str(tree.set(row, tree["columns"][int(col[1:]) - 1]))
        width_px = tree.column(tree["columns"][int(col[1:]) - 1], "width")
        if len(text) * 8 > width_px:               # ข้อความน่าจะยาวเกินช่อง -> ขึ้นข้อความเต็ม
            tip["key"] = key
            tip["after"] = tree.after(350, lambda: show_tip(text, e.x_root, e.y_root))

    tree.bind("<Motion>", on_motion)
    tree.bind("<Leave>", hide_tip)
    tree.bind("<ButtonPress>", hide_tip)
    root.bind_all("<Command-s>" if sys.platform == "darwin" else "<Control-s>", save)
    root.protocol("WM_DELETE_WINDOW", on_close)

    reload()
    clear()
    w, h = 1340, min(max(root.winfo_screenheight() - 100, 700), 980)   # สูงตามหน้าจอ เพื่อให้ตารางเห็นหลายแถว
    root.geometry(f"{w}x{h}+{max((root.winfo_screenwidth() - w) // 2, 0)}+{max((root.winfo_screenheight() - h) // 3, 0)}")
    root.mainloop()


if __name__ == "__main__":
    run_gui()
