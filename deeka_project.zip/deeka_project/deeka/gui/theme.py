"""ธีมสี/ฟอนต์ของหน้าจอ (โทนสว่าง สไตล์แดชบอร์ด)"""
import sys

# สีของธีม (โทนสว่าง สไตล์แดชบอร์ด)
C_BG, C_CARD, C_BORDER = "#F1F5F9", "#FFFFFF", "#E2E8F0"
C_TEXT, C_MUTED = "#0F172A", "#64748B"
C_PRIMARY, C_PRIMARY_HOVER, C_PRIMARY_DOWN = "#2563EB", "#1D4ED8", "#1E40AF"
C_DANGER, C_DANGER_BG = "#DC2626", "#FEF2F2"
C_WAIT, C_SENT, C_DONE = "#F59E0B", "#3B82F6", "#22C55E"           # สีเน้นของการ์ดสถานะ
ROW_WAIT, ROW_SENT, ROW_DONE = "#FFF8E8", "#EEF4FF", "#EDF9F0"     # สีพื้นแถวในตาราง


def apply_theme(root):
    """ตั้งธีมทั้งโปรแกรม: ฟอนต์ สี ปุ่ม ช่องกรอก ตาราง -> คืน (family, ขนาดฟอนต์พื้นฐาน)"""
    from tkinter import font as tkfont
    from tkinter import ttk

    fams = set(tkfont.families(root))
    prefs = {"win32": ["Leelawadee UI", "Segoe UI", "Tahoma"],
             "darwin": []}.get(sys.platform, ["Noto Sans Thai", "Loma", "Sarabun", "DejaVu Sans"])
    default = tkfont.nametofont("TkDefaultFont")
    family = next((p for p in prefs if p in fams), default.actual("family"))
    base = {"darwin": 13, "win32": 10}.get(sys.platform, 11)
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        tkfont.nametofont(name).configure(family=family, size=base)
    root.option_add("*TCombobox*Listbox.font", (family, base))
    root.option_add("*TCombobox*Listbox.background", C_CARD)
    root.option_add("*TCombobox*Listbox.selectBackground", C_PRIMARY)
    root.option_add("*TCombobox*Listbox.selectForeground", "#FFFFFF")
    root.configure(bg=C_BG)

    st = ttk.Style(root)
    st.theme_use("clam")      # ธีมเดียวที่กำหนดสีปุ่ม/ช่องกรอกได้เหมือนกันทุกระบบ
    st.configure(".", background=C_BG, foreground=C_TEXT, font=(family, base),
                 bordercolor=C_BORDER, lightcolor=C_BG, darkcolor=C_BG, focuscolor=C_BG)

    # ป้ายข้อความ
    st.configure("TLabel", background=C_BG, foreground=C_TEXT)
    st.configure("Card.TLabel", background=C_CARD)
    st.configure("Field.TLabel", background=C_CARD, foreground=C_MUTED, font=(family, base - 1))
    st.configure("Muted.TLabel", foreground=C_MUTED, font=(family, base - 1))
    st.configure("H1.TLabel", font=(family, base + 9, "bold"))
    st.configure("H2.TLabel", background=C_CARD, font=(family, base + 1, "bold"))

    # ช่องกรอก / ดรอปดาวน์
    for name in ("App.TEntry", "TCombobox"):
        st.configure(name, fieldbackground=C_CARD, background=C_CARD, foreground=C_TEXT,
                     bordercolor="#CBD5E1", lightcolor="#CBD5E1", darkcolor="#CBD5E1",
                     padding=(8, 6), arrowcolor=C_MUTED, insertcolor=C_TEXT)
        st.map(name, bordercolor=[("focus", C_PRIMARY)], lightcolor=[("focus", C_PRIMARY)],
               darkcolor=[("focus", C_PRIMARY)])
    st.map("TCombobox", fieldbackground=[("readonly", C_CARD)], foreground=[("readonly", C_TEXT)],
           selectbackground=[("readonly", C_CARD)], selectforeground=[("readonly", C_TEXT)])

    # ปุ่ม
    pad = (16, 7)
    st.configure("TButton", padding=pad, relief="solid", borderwidth=1, background=C_CARD,
                 foreground=C_TEXT, bordercolor="#CBD5E1", lightcolor="#CBD5E1", darkcolor="#CBD5E1")
    st.map("TButton", background=[("pressed", "#E2E8F0"), ("active", "#F8FAFC")])
    st.configure("Primary.TButton", background=C_PRIMARY, foreground="#FFFFFF", bordercolor=C_PRIMARY,
                 lightcolor=C_PRIMARY, darkcolor=C_PRIMARY, font=(family, base, "bold"), padding=(20, 7))
    st.map("Primary.TButton", background=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)],
           bordercolor=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)],
           lightcolor=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)],
           darkcolor=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)])
    st.configure("Danger.TButton", foreground=C_DANGER, bordercolor="#FECACA",
                 lightcolor="#FECACA", darkcolor="#FECACA")
    st.map("Danger.TButton", background=[("pressed", "#FEE2E2"), ("active", C_DANGER_BG)])

    # ปุ่มเลือก ✓ / ✗ / ว่าง
    for name, on in (("Blank", "#E2E8F0"), ("Yes", "#DCFCE7"), ("No", "#FEE2E2")):
        st.configure(f"{name}.Toolbutton", background=C_CARD, foreground=C_MUTED, padding=(14, 5),
                     relief="solid", borderwidth=1, bordercolor="#CBD5E1", lightcolor="#CBD5E1",
                     darkcolor="#CBD5E1", anchor="center")
        st.map(f"{name}.Toolbutton", background=[("selected", on), ("active", "#F8FAFC")],
               foreground=[("selected", {"Blank": C_TEXT, "Yes": "#15803D", "No": C_DANGER}[name])],
               bordercolor=[("selected", {"Blank": "#94A3B8", "Yes": "#22C55E", "No": "#F87171"}[name])])

    # ตาราง
    st.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])   # ตัดขอบเดิมออก
    st.configure("Treeview", background=C_CARD, fieldbackground=C_CARD, foreground=C_TEXT,
                 rowheight=int(base * 2.7), borderwidth=0)
    st.map("Treeview", background=[("selected", "#BFDBFE")], foreground=[("selected", C_TEXT)])
    st.configure("Treeview.Heading", background="#F8FAFC", foreground=C_MUTED, relief="flat",
                 font=(family, base - 1, "bold"), padding=(8, 8), bordercolor=C_BORDER,
                 lightcolor="#F8FAFC", darkcolor="#F8FAFC")
    st.map("Treeview.Heading", background=[("active", "#EEF2F7")])
    st.configure("Vertical.TScrollbar", background="#CBD5E1", troughcolor=C_CARD, bordercolor=C_CARD,
                 arrowcolor=C_CARD, lightcolor="#CBD5E1", darkcolor="#CBD5E1", gripcount=0)
    st.map("Vertical.TScrollbar", background=[("active", "#94A3B8")])
    st.configure("Horizontal.TScrollbar", background="#CBD5E1", troughcolor=C_CARD, bordercolor=C_CARD,
                 arrowcolor=C_CARD, lightcolor="#CBD5E1", darkcolor="#CBD5E1", gripcount=0)
    st.map("Horizontal.TScrollbar", background=[("active", "#94A3B8")])
    return family, base
