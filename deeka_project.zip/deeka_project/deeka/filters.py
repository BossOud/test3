"""สถานะฎีกา ปีงบประมาณ และตัวกรองรายการ"""
from datetime import date

from .formats import TICK_YES, fmt_thai_date, parse_thai_date, tick_of


# ---------------------------------------------------------------- สถานะ / ตัวกรอง
ST_WAIT, ST_SENT, ST_DONE = "รอส่งมอบ", "ส่งมอบแล้ว", "รับมอบแล้ว"
STATUSES = [ST_WAIT, ST_SENT, ST_DONE]
ALL = "ทั้งหมด"


def status_of(r) -> str:
    """สถานะคำนวณเอง: มีวันที่รับมอบ หรือ ติ๊ก ✓ ผู้รับมอบ = รับมอบแล้ว ; มีวันที่ส่งมอบ หรือ ติ๊ก ✓ ผู้ส่งมอบ = ส่งมอบแล้ว ; ไม่มีเลย = รอส่งมอบ"""
    if r["receive"] or tick_of(r["receiver"]) == TICK_YES:
        return ST_DONE
    if r["handover"] or tick_of(r["sender"]) == TICK_YES:
        return ST_SENT
    return ST_WAIT


def fiscal_year(iso: str) -> int:
    """ปีงบประมาณ (พ.ศ.) เริ่ม 1 ต.ค. เช่น 15/10/2568 -> 2569"""
    d = date.fromisoformat(iso)
    return d.year + 543 + (1 if d.month >= 10 else 0)


def parse_filters(raw: dict) -> dict:
    """แปลงค่าจากช่องตัวกรอง (ข้อความ) -> dict พร้อมใช้ ; ค่า 'ทั้งหมด'/ว่าง = ไม่กรอง"""
    f = {k: ("" if raw.get(k, "") in (ALL, None) else str(raw.get(k, "")).strip())
         for k in ("fy", "plan", "expense_type", "status")}
    try:
        d1, d2 = parse_thai_date(raw.get("date_from")), parse_thai_date(raw.get("date_to"))
    except ValueError as e:
        raise ValueError(f"ตัวกรองวันที่: {e}")
    if d1 and d2 and d2 < d1:
        raise ValueError("ตัวกรองวันที่: 'ถึงวันที่' ต้องไม่ก่อน 'ตั้งแต่วันที่'")
    f["date_from"] = d1.isoformat() if d1 else ""
    f["date_to"] = d2.isoformat() if d2 else ""
    if f["fy"] and not f["fy"].isdigit():
        raise ValueError("ปีงบประมาณต้องเป็นตัวเลข เช่น 2569")
    return f


def filter_rows(rows, f: dict):
    out = []
    for r in rows:
        if f.get("date_from") and r["created"] < f["date_from"]:
            continue
        if f.get("date_to") and r["created"] > f["date_to"]:
            continue
        if f.get("fy") and fiscal_year(r["created"]) != int(f["fy"]):
            continue
        if f.get("plan") and r["plan"] != f["plan"]:
            continue
        if f.get("expense_type") and r["expense_type"] != f["expense_type"]:
            continue
        if f.get("status") and status_of(r) != f["status"]:
            continue
        out.append(r)
    return out


def describe_filters(f: dict, keyword: str = "") -> str:
    parts = []
    if keyword.strip():
        parts.append(f"คำค้น \"{keyword.strip()}\"")
    if f.get("fy"):
        parts.append(f"ปีงบประมาณ {f['fy']}")
    if f.get("date_from") or f.get("date_to"):
        parts.append(f"วันที่จัดทำ {fmt_thai_date(f.get('date_from')) or '...'} ถึง "
                     f"{fmt_thai_date(f.get('date_to')) or '...'}")
    for key, label in (("plan", "แผนงาน"), ("expense_type", "ประเภท"), ("status", "สถานะ")):
        if f.get(key):
            parts.append(f"{label}: {f[key]}")
    return " | ".join(parts)   # ว่าง = ไม่มีตัวกรอง (ไม่ต้องพิมพ์บรรทัดตัวกรอง)
