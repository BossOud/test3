"""รูปแบบข้อมูล: เครื่องหมาย ✓/✗, วันที่ไทย (4 พ.ย. 69), จำนวนเงิน"""
import re
from datetime import date
from decimal import Decimal, InvalidOperation


# ---------------------------------------------------------------- ✓ / ✗ (ผู้ส่งมอบ / ผู้รับมอบ)
TICK_YES, TICK_NO = "✓", "✗"
TICKS = ("", TICK_YES, TICK_NO)


def tick_of(v) -> str:
    """ค่าที่เก็บไว้ -> ✓/✗/ว่าง (ข้อมูลเก่าที่เป็นชื่อคน ถือว่า ✓ เพราะมีการส่ง/รับมอบแล้ว)"""
    v = (v or "").strip()
    return v if v in TICKS else TICK_YES


# ---------------------------------------------------------------- date / money
THAI_ABBR = ["", "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.",
             "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."]
THAI_FULL = ["", "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
             "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"]
_DATE_NUM = re.compile(r"^(\d{1,2})[/\-.\s](\d{1,2})[/\-.\s](\d{2,4})$")
_DATE_NAME = re.compile(r"^(\d{1,2})\s*([ก-๙.]+)\s*(\d{2,4})$")


def _month_from_name(name: str) -> int:
    key = name.replace(".", "")
    for i in range(1, 13):
        if key in (THAI_ABBR[i].replace(".", ""), THAI_FULL[i]):
            return i
    raise ValueError("ชื่อเดือนไม่ถูกต้อง")


def parse_thai_date(text: str):
    """รับได้หลายแบบ: '4 พ.ย. 69', '4 พ.ย. 2569', '4/11/69', '04/11/2569', '4 11 69'
    (ปี 2 หลัก = พ.ศ. 25xx ; ปี 4 หลักที่ต่ำกว่า 2400 ถือเป็น ค.ศ.)
    ค่าว่าง -> None ; ผิด -> ValueError"""
    text = (text or "").strip()
    if not text:
        return None
    try:
        m = _DATE_NUM.match(text)
        if m:
            d, mo, y = int(m[1]), int(m[2]), m[3]
        else:
            m = _DATE_NAME.match(text)
            if not m:
                raise ValueError
            d, mo, y = int(m[1]), _month_from_name(m[2]), m[3]
        if len(y) == 3:
            raise ValueError
        yi = int(y)
        if len(y) == 2:
            yi += 2500
        elif yi < 2400:          # ผู้ใช้กรอก ค.ศ. มา
            yi += 543
        return date(yi - 543, mo, d)
    except (ValueError, TypeError):
        raise ValueError(f"วันที่ '{text}' ไม่ถูกต้อง (พิมพ์เช่น 4 พ.ย. 69 หรือ 4/11/69)")


def fmt_thai_date(iso: str) -> str:
    """'2026-11-04' -> '4 พ.ย. 69'"""
    if not iso:
        return ""
    d = date.fromisoformat(iso)
    return f"{d.day} {THAI_ABBR[d.month]} {(d.year + 543) % 100:02d}"


def parse_amount(text: str) -> int:
    """'12,345.50' -> 1234550 (สตางค์) เก็บเป็นจำนวนเต็มเพื่อกันทศนิยมเพี้ยน"""
    try:
        v = Decimal((text or "").replace(",", "").strip())
    except InvalidOperation:
        raise ValueError("จำนวนเงินต้องเป็นตัวเลข เช่น 12,345.50")
    if v <= 0:
        raise ValueError("จำนวนเงินต้องมากกว่า 0")
    if v.as_tuple().exponent < -2:
        raise ValueError("จำนวนเงินมีทศนิยมได้ไม่เกิน 2 ตำแหน่ง")
    return int(v * 100)


def fmt_amount(satang: int) -> str:
    return f"{satang / 100:,.2f}"
