"""ไฟล์ตั้งค่า config.ini และไฟล์ log"""
import configparser
import logging

from . import paths

DEFAULT_CONFIG = """[files]
database = data/deeka.db
log = logs/deeka.log
backup_dir = backup
export_dir = export
; สำรองอัตโนมัติทุกครั้งที่ปิดโปรแกรม (ถ้ามีการแก้ไขข้อมูล) เก็บไฟล์ล่าสุดไว้กี่ไฟล์
backup_keep = 30
; ไฟล์รายการ แผนงาน / งาน / รายจ่าย / ประเภทรายจ่าย ที่ใช้เลือกในโปรแกรม (แก้ไขด้วย Notepad ได้)
lists = config/lists.txt

[retry]
; ถ้าไฟล์ฐานข้อมูลถูกล็อก (เช่น เปิดซ้อนหลายโปรแกรม) ให้ลองใหม่กี่ครั้ง / รอกี่วินาที
times = 3
wait_seconds = 1
"""


def load_config() -> configparser.ConfigParser:
    if not paths.CONFIG_FILE.exists():
        paths.CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        paths.CONFIG_FILE.write_text(DEFAULT_CONFIG, encoding="utf-8")
    cfg = configparser.ConfigParser()
    cfg.read(paths.CONFIG_FILE, encoding="utf-8")
    return cfg

def setup_logging(cfg) -> None:
    logging.basicConfig(
        filename=paths.BASE_DIR / cfg["files"]["log"],
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        encoding="utf-8",
    )
