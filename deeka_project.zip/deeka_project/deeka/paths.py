"""ที่อยู่ของโฟลเดอร์/ไฟล์ทั้งหมด + การย้ายไฟล์รุ่นเก่าเข้าโฟลเดอร์"""
import re
import shutil
import sys
from pathlib import Path

# โฟลเดอร์หลัก = โฟลเดอร์ของ main.py (หรือของไฟล์ .exe ที่สร้างด้วย PyInstaller)
BASE_DIR = (Path(sys.executable).resolve().parent if getattr(sys, "frozen", False)
            else Path(__file__).resolve().parent.parent)
DATA_DIR = BASE_DIR / "data"          # ฐานข้อมูล
CONFIG_DIR = BASE_DIR / "config"      # config.ini + lists.txt
LOG_DIR = BASE_DIR / "logs"           # ไฟล์ log
CONFIG_FILE = CONFIG_DIR / "config.ini"


def migrate_layout() -> None:
    """สร้างโฟลเดอร์ และย้ายไฟล์ของรุ่นเก่า (ที่วางรวมกันข้างตัวโปรแกรม) เข้าโฟลเดอร์ให้เอง ข้อมูลไม่หาย"""
    for folder in (DATA_DIR, CONFIG_DIR, LOG_DIR, BASE_DIR / "backup", BASE_DIR / "export"):
        folder.mkdir(parents=True, exist_ok=True)
    for old, new in (("config.ini", CONFIG_FILE), ("lists.txt", CONFIG_DIR / "lists.txt"),
                     ("lists_old.txt", CONFIG_DIR / "lists_old.txt"),
                     ("deeka.db", DATA_DIR / "deeka.db"), ("deeka.log", LOG_DIR / "deeka.log")):
        src = BASE_DIR / old
        if src.is_file() and not new.exists():
            shutil.move(str(src), str(new))
    if CONFIG_FILE.exists():      # config.ini รุ่นเก่าชี้ไปที่ไฟล์ข้างโปรแกรม -> ปรับให้ชี้เข้าโฟลเดอร์
        text = old_text = CONFIG_FILE.read_text(encoding="utf-8")
        for key, old_val, new_val in (("database", "deeka.db", "data/deeka.db"), ("log", "deeka.log", "logs/deeka.log"),
                                      ("lists", "lists.txt", "config/lists.txt")):
            text = re.sub(rf"(?m)^({key}\s*=\s*){re.escape(old_val)}\s*$", rf"\g<1>{new_val}", text)
        if text != old_text:
            CONFIG_FILE.write_text(text, encoding="utf-8")
