"""ฐานข้อมูล SQLite: เพิ่ม/แก้ไข/ลบ/ค้นหา/สำรอง"""
import logging
import shutil
import sqlite3
import time
from datetime import datetime
from pathlib import Path


SCHEMA = """
CREATE TABLE IF NOT EXISTS deeka (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    no            TEXT NOT NULL UNIQUE,     -- ที่
    created       TEXT NOT NULL,            -- วันที่จัดทำ (ISO ค.ศ.)
    subject       TEXT NOT NULL,            -- ฎีกาเรื่อง
    plan          TEXT NOT NULL,            -- แผนงาน
    task          TEXT DEFAULT '',          -- งาน (อยู่ใต้แผนงาน)
    expense_type  TEXT NOT NULL,            -- รายจ่าย (เช่น ค่าวัสดุ)
    expense_item  TEXT DEFAULT '',          -- ประเภทรายจ่าย (อยู่ใต้รายจ่าย เช่น วัสดุสำนักงาน)
    amount        INTEGER NOT NULL,         -- จำนวนเงิน (สตางค์)
    sender        TEXT DEFAULT '',          -- ผู้ส่งมอบ
    handover      TEXT DEFAULT '',          -- วันที่ส่งมอบ
    receiver      TEXT DEFAULT '',          -- ผู้รับมอบ
    receive       TEXT DEFAULT '',          -- วันที่รับมอบ
    note          TEXT DEFAULT '',          -- หมายเหตุ
    updated_at    TEXT DEFAULT CURRENT_TIMESTAMP
);
"""
COLS = ("no", "created", "subject", "plan", "task", "expense_type", "expense_item", "amount",
        "sender", "handover", "receiver", "receive", "note")


class Database:
    def __init__(self, path: Path, retry_times=3, retry_wait=1.0):
        self.retry_times, self.retry_wait = retry_times, retry_wait
        self.path = path
        self.conn = sqlite3.connect(path, timeout=5)
        self.conn.row_factory = sqlite3.Row
        self._run(lambda: (self.conn.executescript(SCHEMA), self.conn.commit()))
        # ฐานข้อมูลเก่าที่ยังไม่มีคอลัมน์ "งาน" -> เพิ่มให้ (ข้อมูลเดิมไม่หาย)
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(deeka)")}
        for col in ("task", "expense_item"):
            if col not in cols:
                self._run(lambda c=col: (self.conn.execute(f"ALTER TABLE deeka ADD COLUMN {c} TEXT DEFAULT ''"),
                                         self.conn.commit()))
                logging.info("เพิ่มคอลัมน์ %s ในฐานข้อมูลเดิม", col)

    def _run(self, fn):
        """รันคำสั่ง และลองใหม่เมื่อไฟล์ถูกล็อก"""
        for attempt in range(1, self.retry_times + 1):
            try:
                return fn()
            except sqlite3.OperationalError as e:
                logging.warning("DB error (ครั้งที่ %s/%s): %s", attempt, self.retry_times, e)
                if attempt == self.retry_times:
                    raise
                time.sleep(self.retry_wait)

    def next_no(self) -> str:
        nums = [int(r["no"]) for r in self.conn.execute("SELECT no FROM deeka") if r["no"].isdigit()]
        return str(max(nums, default=0) + 1)

    def add(self, rec: dict) -> int:
        def go():
            cur = self.conn.execute(
                f"INSERT INTO deeka ({','.join(COLS)}) VALUES ({','.join('?' * len(COLS))})",
                [rec[c] for c in COLS])
            self.conn.commit()
            return cur.lastrowid
        try:
            rid = self._run(go)
        except sqlite3.IntegrityError:
            raise ValueError(f"เลขที่ '{rec['no']}' มีอยู่แล้ว")
        logging.info("เพิ่ม ที่=%s เรื่อง=%s", rec["no"], rec["subject"])
        return rid

    def update(self, rid: int, rec: dict) -> None:
        def go():
            sets = ",".join(f"{c}=?" for c in COLS)
            self.conn.execute(f"UPDATE deeka SET {sets}, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                              [rec[c] for c in COLS] + [rid])
            self.conn.commit()
        try:
            self._run(go)
        except sqlite3.IntegrityError:
            raise ValueError(f"เลขที่ '{rec['no']}' มีอยู่แล้ว")
        logging.info("แก้ไข id=%s ที่=%s", rid, rec["no"])

    def delete(self, rid: int) -> None:
        self._run(lambda: (self.conn.execute("DELETE FROM deeka WHERE id=?", (rid,)), self.conn.commit()))
        logging.info("ลบ id=%s", rid)

    def get(self, rid: int):
        return self.conn.execute("SELECT * FROM deeka WHERE id=?", (rid,)).fetchone()

    def search(self, keyword: str = ""):
        k = f"%{keyword.strip()}%"
        return self.conn.execute(
            "SELECT * FROM deeka WHERE no LIKE ? OR subject LIKE ? OR plan LIKE ? "
            "OR task LIKE ? OR expense_type LIKE ? OR expense_item LIKE ? OR note LIKE ? "
            "ORDER BY CAST(no AS INTEGER), no", (k,) * 7).fetchall()

    def backup(self, folder: Path, keep: int = 0) -> Path:
        """สำรองฐานข้อมูล; keep>0 = เก็บไฟล์สำรองล่าสุดไว้กี่ไฟล์ (ที่เก่ากว่าลบทิ้ง)"""
        folder.mkdir(exist_ok=True)
        dest = folder / f"deeka_{datetime.now():%Y%m%d_%H%M%S}.db"
        self.conn.commit()
        shutil.copy2(self.path, dest)
        logging.info("สำรองข้อมูล -> %s", dest)
        if keep > 0:
            for old in sorted(folder.glob("deeka_*.db"))[:-keep]:
                try:
                    old.unlink()
                    logging.info("ลบไฟล์สำรองเก่า %s", old.name)
                except OSError:
                    logging.warning("ลบไฟล์สำรองเก่าไม่ได้: %s", old)
        return dest
