# -*- coding: utf-8 -*-
"""จุดเริ่มต้นของโปรแกรมทะเบียนการจัดทำฎีกา  (รันด้วย: python main.py)"""
from deeka.gui.main_window import run_gui

if __name__ == "__main__":
    run_gui()
