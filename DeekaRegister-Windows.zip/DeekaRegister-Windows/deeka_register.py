# -*- coding: utf-8 -*-
"""
โปรแกรมทะเบียนการจัดทำฎีกา (Python + Tkinter + SQLite)
- ไม่ต้องติดตั้งไลบรารีเพิ่ม (ใช้ของที่มากับ Python)
- ข้อมูลเก็บในไฟล์ deeka.db (ไฟล์เดียว) ตั้งค่าได้ใน config.ini
- วันที่แสดง/กรอกเป็น พ.ศ. รูปแบบ 4 พ.ย. 69 (พิมพ์ 4/11/69 ก็ได้ ระบบแปลงให้)
"""
import configparser
import csv
import logging
import re
import shutil
import sqlite3
import sys
import time
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

BASE_DIR = Path(getattr(sys, "frozen", False) and sys.executable or __file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.ini"

DEFAULT_CONFIG = """[files]
database = deeka.db
log = deeka.log
backup_dir = backup
export_dir = export
; สำรองอัตโนมัติทุกครั้งที่ปิดโปรแกรม (ถ้ามีการแก้ไขข้อมูล) เก็บไฟล์ล่าสุดไว้กี่ไฟล์
backup_keep = 30
; ไฟล์รายการ แผนงาน / งาน / ประเภทรายจ่าย ที่ใช้เลือกในโปรแกรม (แก้ไขด้วย Notepad ได้)
lists = lists.txt

[retry]
; ถ้าไฟล์ฐานข้อมูลถูกล็อก (เช่น เปิดซ้อนหลายโปรแกรม) ให้ลองใหม่กี่ครั้ง / รอกี่วินาที
times = 3
wait_seconds = 1
"""


# ---------------------------------------------------------------- config / log
DEFAULT_LISTS = """# รายการแผนงาน / งาน / ประเภทรายจ่าย / รายการรายจ่าย ที่ใช้เลือกในโปรแกรม (แก้ไขด้วย Notepad แล้วเปิดโปรแกรมใหม่)
# บรรทัดที่ไม่ขึ้นต้นด้วย - คือ "แผนงาน" (หรือ "ประเภทรายจ่าย" ในส่วน [ประเภทรายจ่าย])
# บรรทัดที่ขึ้นต้นด้วย - คือ "งาน" (หรือ "รายการรายจ่าย") ของบรรทัดหลักที่อยู่ด้านบน
# บรรทัดที่ขึ้นต้นด้วย # คือหมายเหตุ (โปรแกรมไม่อ่าน)
แผนงานบริหารงานทั่วไป
-งานบริหาร
-งานวางแผนสถิติและวิชาการ
-งานบริหารการคลัง
-งานควบคุมภายในและการตรวจสอบภายใน
-งานสารสนเทศ
แผนงานการรักษาความสงบภายใน
-งานบริหารทั่วไปเกี่ยวกับการรักษาความสงบภายใน
-งานเทศกิจ
-งานป้องกันและบรรเทาสาธารณภัย
-งานจราจร
แผนงานการศึกษา
-งานบริหารทั่วไปเกี่ยวกับการศึกษา
-งานระดับก่อนวัยเรียนและประถมศึกษา
-งานระดับมัธยมศึกษา
-งานศึกษาไม่กำหนดระดับ
แผนงานสาธารณสุข
-งานบริหารทั่วไปเกี่ยวกับสาธารณสุข
-งานโรงพยาบาล
-งานบริการสาธารณสุขและงานสาธารณสุขอื่น
-งานศูนย์บริการสาธารณสุข
แผนงานสังคมสงเคราะห์
-งานบริหารทั่วไปเกี่ยวกับสังคมสงเคราะห์
-งานสวัสดิการสังคมและสังคมสงเคราะห์
แผนงานเคหะและชุมชน
-งานบริหารทั่วไปเกี่ยวกับเคหะและชุมชน
-งานไฟฟ้าและประปา
-งานกำจัดขยะมูลฝอยและสิ่งปฏิกูล
-งานบำบัดน้ำเสีย
แผนงานสร้างความเข้มแข็งของชุมชน
-งานบริหารทั่วไปเกี่ยวกับสร้างความเข้มแข็งของชุมชน
-งานส่งเสริมและสนับสนุนความเข้มแข็งชุมชน
แผนงานการศาสนา วัฒนธรรม และนันทนาการ
-งานบริหารทั่วไปเกี่ยวกับศาสนา วัฒนธรรม และนันทนาการ
-งานศาสนาวัฒนธรรมท้องถิ่น
-งานวิชาการวางแผนและส่งเสริมการท่องเที่ยว
แผนงานอุตสาหกรรมและการโยธา
-งานบริหารทั่วไปเกี่ยวกับอุตสาหกรรมและการโยธา
-งานก่อสร้าง
แผนงานการเกษตร
-งานส่งเสริมการเกษตร
-งานสิ่งแวดล้อมและทรัพยากรธรรมชาติ
แผนงานการพาณิชย์
-งานกิจการสถานธนานุบาล
-งานกิจการประปา
-งานตลาดสด
-งานโรงฆ่าสัตว์
-งานกิจการสถานีขนส่ง/กิจการท่าเรือ
-งานกิจการพาณิชย์อื่นๆ

[ประเภทรายจ่าย]
ค่าตอบแทน
-ค่าตอบแทนผู้ปฏิบัติราชการอันเป็นประโยชน์แก่องค์กรปกครองส่วนท้องถิ่น
-ค่าเบี้ยประชุม
-ค่าตอบแทนการปฏิบัติงานนอกเวลาราชการ
-ค่าเช่าบ้าน
-เงินช่วยเหลือการศึกษาบุตร
-เงินช่วยเหลือค่ารักษาพยาบาล
ค่าใช้สอย
-รายจ่ายเพื่อให้ได้มาซึ่งบริการ
-รายจ่ายเกี่ยวกับการรับรองและพิธีการ
-รายจ่ายเกี่ยวเนื่องกับการปฏิบัติราชการที่ไม่เข้าลักษณะรายจ่ายงบรายจ่ายอื่นๆ
-ค่าบำรุงรักษาและซ่อมแซม
ค่าวัสดุ
-วัสดุสำนักงาน
-วัสดุไฟฟ้าและวิทยุ
-วัสดุงานบ้านงานครัว
-วัสดุก่อสร้าง
-วัสดุยานพาหนะและขนส่ง
-วัสดุเชื้อเพลิงและหล่อลื่น
-วัสดุวิทยาศาสตร์หรือการแพทย์
-วัสดุการเกษตร
-วัสดุโฆษณาและเผยแพร่
-วัสดุเครื่องแต่งกาย
-วัสดุกีฬา
-วัสดุคอมพิวเตอร์
-วัสดุการศึกษา
-วัสดุเครื่องดับเพลิง
ค่าสาธารณูปโภค
-ค่าไฟฟ้า
-ค่าน้ำประปา ค่าน้ำบาดาล
-ค่าบริการโทรศัพท์
-ค่าบริการไปรษณีย์
-ค่าบริการสื่อสารและโทรคมนาคม
-ค่าเช่าพื้นที่เว็บไซต์และค่าธรรมเนียมที่เกี่ยวข้อง
"""

# แฮชของ lists.txt ค่าเริ่มต้นรุ่นเก่า -> ถ้าผู้ใช้ยังไม่เคยแก้ไฟล์ จะอัปเดตเป็นรุ่นใหม่ให้อัตโนมัติ
LEGACY_LISTS_SHA256 = {"484ff68a06ed45a85b3ca68a6f0b44fd6766e06f0ce2e178a2a034575d68c69b"}


def load_lists(path: Path):
    """อ่าน lists.txt -> (แผนงาน, {แผนงาน: [งาน]}, ประเภทรายจ่าย, {ประเภท: [รายการรายจ่าย]})
    ถ้ายังไม่มีไฟล์ จะสร้างจากค่าเริ่มต้นให้"""
    import hashlib
    if path.exists():
        old = path.read_text(encoding="utf-8-sig")
        if hashlib.sha256(old.encode("utf-8")).hexdigest() in LEGACY_LISTS_SHA256:
            shutil.copy2(path, path.with_name(path.stem + "_old" + path.suffix))
            path.write_text(DEFAULT_LISTS, encoding="utf-8")
            logging.info("อัปเดต %s เป็นรายการรุ่นใหม่ (เก็บฉบับเก่าไว้เป็น *_old)", path.name)
    else:
        path.write_text(DEFAULT_LISTS, encoding="utf-8")
    sec = {"plan": ([], {}), "type": ([], {})}
    mode, cur = "plan", None
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if (line.startswith("[") and line.endswith("]")) or line == "ประเภทรายจ่าย":
            mode, cur = ("type" if "ประเภทรายจ่าย" in line else "plan"), None
            continue
        item = line.lstrip("-").strip()
        if not item:
            continue
        names, kids = sec[mode]
        if line.startswith("-"):
            if cur is not None:
                kids[cur].append(item)
        else:
            cur = item
            names.append(cur)
            kids.setdefault(cur, [])
    return sec["plan"][0], sec["plan"][1], sec["type"][0], sec["type"][1]


def load_config() -> configparser.ConfigParser:
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(DEFAULT_CONFIG, encoding="utf-8")
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_FILE, encoding="utf-8")
    return cfg


def setup_logging(cfg) -> None:
    logging.basicConfig(
        filename=BASE_DIR / cfg["files"]["log"],
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        encoding="utf-8",
    )


# ---------------------------------------------------------------- ✓ / ✗ (ผู้ส่งมอบ / ผู้รับมอบ)
TICK_YES, TICK_NO = "✓", "✗"
TICKS = ("", TICK_YES, TICK_NO)


def tick_of(v) -> str:
    """ค่าที่เก็บไว้ -> ✓/✗/ว่าง (ข้อมูลเก่าที่เป็นชื่อคน ถือว่า ✓ เพราะมีการส่ง/รับมอบแล้ว)"""
    v = (v or "").strip()
    return v if v in TICKS else TICK_YES


# ---------------------------------------------------------------- date / money
THAI_ABBR = ["", "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.",
             "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."]
THAI_FULL = ["", "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
             "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"]
_DATE_NUM = re.compile(r"^(\d{1,2})[/\-.\s](\d{1,2})[/\-.\s](\d{2,4})$")
_DATE_NAME = re.compile(r"^(\d{1,2})\s*([ก-๙.]+)\s*(\d{2,4})$")


def _month_from_name(name: str) -> int:
    key = name.replace(".", "")
    for i in range(1, 13):
        if key in (THAI_ABBR[i].replace(".", ""), THAI_FULL[i]):
            return i
    raise ValueError("ชื่อเดือนไม่ถูกต้อง")


def parse_thai_date(text: str):
    """รับได้หลายแบบ: '4 พ.ย. 69', '4 พ.ย. 2569', '4/11/69', '04/11/2569', '4 11 69'
    (ปี 2 หลัก = พ.ศ. 25xx ; ปี 4 หลักที่ต่ำกว่า 2400 ถือเป็น ค.ศ.)
    ค่าว่าง -> None ; ผิด -> ValueError"""
    text = (text or "").strip()
    if not text:
        return None
    try:
        m = _DATE_NUM.match(text)
        if m:
            d, mo, y = int(m[1]), int(m[2]), m[3]
        else:
            m = _DATE_NAME.match(text)
            if not m:
                raise ValueError
            d, mo, y = int(m[1]), _month_from_name(m[2]), m[3]
        if len(y) == 3:
            raise ValueError
        yi = int(y)
        if len(y) == 2:
            yi += 2500
        elif yi < 2400:          # ผู้ใช้กรอก ค.ศ. มา
            yi += 543
        return date(yi - 543, mo, d)
    except (ValueError, TypeError):
        raise ValueError(f"วันที่ '{text}' ไม่ถูกต้อง (พิมพ์เช่น 4 พ.ย. 69 หรือ 4/11/69)")


def fmt_thai_date(iso: str) -> str:
    """'2026-11-04' -> '4 พ.ย. 69'"""
    if not iso:
        return ""
    d = date.fromisoformat(iso)
    return f"{d.day} {THAI_ABBR[d.month]} {(d.year + 543) % 100:02d}"


def parse_amount(text: str) -> int:
    """'12,345.50' -> 1234550 (สตางค์) เก็บเป็นจำนวนเต็มเพื่อกันทศนิยมเพี้ยน"""
    try:
        v = Decimal((text or "").replace(",", "").strip())
    except InvalidOperation:
        raise ValueError("จำนวนเงินต้องเป็นตัวเลข เช่น 12,345.50")
    if v <= 0:
        raise ValueError("จำนวนเงินต้องมากกว่า 0")
    if v.as_tuple().exponent < -2:
        raise ValueError("จำนวนเงินมีทศนิยมได้ไม่เกิน 2 ตำแหน่ง")
    return int(v * 100)


def fmt_amount(satang: int) -> str:
    return f"{satang / 100:,.2f}"


# ---------------------------------------------------------------- validation
def validate(form: dict) -> dict:
    """ตรวจฟอร์ม -> คืน dict พร้อมบันทึก หรือ raise ValueError(รายการข้อผิดพลาด)"""
    errors, out = [], {}

    def need(key, label):
        v = (form.get(key) or "").strip()
        if not v:
            errors.append(f"กรุณากรอก{label}")
        return v

    out["no"] = need("no", "ที่")
    out["subject"] = need("subject", "ฎีกาเรื่อง")
    out["plan"] = need("plan", "แผนงาน")
    out["task"] = (form.get("task") or "").strip()      # งาน (ไม่บังคับ)
    out["expense_type"] = need("expense_type", "ประเภทรายจ่าย")
    out["expense_item"] = (form.get("expense_item") or "").strip()   # รายการรายจ่าย (ไม่บังคับ)
    out["note"] = (form.get("note") or "").strip()

    dates = {}
    for key, label, required in (
        ("created", "วันที่จัดทำ", True),
        ("handover", "วันที่ผู้ส่งมอบ", False),
        ("receive", "วันที่ผู้รับมอบ", False),
    ):
        try:
            d = parse_thai_date(form.get(key))
            if d is None and required:
                errors.append(f"กรุณากรอก{label}")
            dates[key] = d
        except ValueError as e:
            errors.append(f"{label}: {e}")
    try:
        out["amount"] = parse_amount(form.get("amount"))
    except ValueError as e:
        errors.append(str(e))

    c, h, r = dates.get("created"), dates.get("handover"), dates.get("receive")
    if c and h and h < c:
        errors.append("วันที่ส่งมอบต้องไม่ก่อนวันที่จัดทำ")
    if h and r and r < h:
        errors.append("วันที่รับมอบต้องไม่ก่อนวันที่ส่งมอบ")

    # ผู้ส่งมอบ / ผู้รับมอบ และวันที่ ไม่บังคับกรอก (เว้นว่างได้ทั้งหมด)
    for key, label in (("sender", "ผู้ส่งมอบ"), ("receiver", "ผู้รับมอบ")):
        v = (form.get(key) or "").strip()
        if v not in TICKS:
            errors.append(f"{label}ต้องเลือก ✓ หรือ ✗ (หรือเว้นว่าง)")
        out[key] = v

    if errors:
        raise ValueError("\n".join(errors))
    for key in dates:
        out[key] = dates[key].isoformat() if dates[key] else ""
    return out


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS deeka (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    no            TEXT NOT NULL UNIQUE,     -- ที่
    created       TEXT NOT NULL,            -- วันที่จัดทำ (ISO ค.ศ.)
    subject       TEXT NOT NULL,            -- ฎีกาเรื่อง
    plan          TEXT NOT NULL,            -- แผนงาน
    task          TEXT DEFAULT '',          -- งาน (อยู่ใต้แผนงาน)
    expense_type  TEXT NOT NULL,            -- ประเภทรายจ่าย
    expense_item  TEXT DEFAULT '',          -- รายการรายจ่าย (อยู่ใต้ประเภท)
    amount        INTEGER NOT NULL,         -- จำนวนเงิน (สตางค์)
    sender        TEXT DEFAULT '',          -- ผู้ส่งมอบ
    handover      TEXT DEFAULT '',          -- วันที่ส่งมอบ
    receiver      TEXT DEFAULT '',          -- ผู้รับมอบ
    receive       TEXT DEFAULT '',          -- วันที่รับมอบ
    note          TEXT DEFAULT '',          -- หมายเหตุ
    updated_at    TEXT DEFAULT CURRENT_TIMESTAMP
);
"""
COLS = ("no", "created", "subject", "plan", "task", "expense_type", "expense_item", "amount",
        "sender", "handover", "receiver", "receive", "note")


class Database:
    def __init__(self, path: Path, retry_times=3, retry_wait=1.0):
        self.retry_times, self.retry_wait = retry_times, retry_wait
        self.path = path
        self.conn = sqlite3.connect(path, timeout=5)
        self.conn.row_factory = sqlite3.Row
        self._run(lambda: (self.conn.executescript(SCHEMA), self.conn.commit()))
        # ฐานข้อมูลเก่าที่ยังไม่มีคอลัมน์ "งาน" -> เพิ่มให้ (ข้อมูลเดิมไม่หาย)
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(deeka)")}
        for col in ("task", "expense_item"):
            if col not in cols:
                self._run(lambda c=col: (self.conn.execute(f"ALTER TABLE deeka ADD COLUMN {c} TEXT DEFAULT ''"),
                                         self.conn.commit()))
                logging.info("เพิ่มคอลัมน์ %s ในฐานข้อมูลเดิม", col)

    def _run(self, fn):
        """รันคำสั่ง และลองใหม่เมื่อไฟล์ถูกล็อก"""
        for attempt in range(1, self.retry_times + 1):
            try:
                return fn()
            except sqlite3.OperationalError as e:
                logging.warning("DB error (ครั้งที่ %s/%s): %s", attempt, self.retry_times, e)
                if attempt == self.retry_times:
                    raise
                time.sleep(self.retry_wait)

    def next_no(self) -> str:
        nums = [int(r["no"]) for r in self.conn.execute("SELECT no FROM deeka") if r["no"].isdigit()]
        return str(max(nums, default=0) + 1)

    def add(self, rec: dict) -> int:
        def go():
            cur = self.conn.execute(
                f"INSERT INTO deeka ({','.join(COLS)}) VALUES ({','.join('?' * len(COLS))})",
                [rec[c] for c in COLS])
            self.conn.commit()
            return cur.lastrowid
        try:
            rid = self._run(go)
        except sqlite3.IntegrityError:
            raise ValueError(f"เลขที่ '{rec['no']}' มีอยู่แล้ว")
        logging.info("เพิ่ม ที่=%s เรื่อง=%s", rec["no"], rec["subject"])
        return rid

    def update(self, rid: int, rec: dict) -> None:
        def go():
            sets = ",".join(f"{c}=?" for c in COLS)
            self.conn.execute(f"UPDATE deeka SET {sets}, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                              [rec[c] for c in COLS] + [rid])
            self.conn.commit()
        try:
            self._run(go)
        except sqlite3.IntegrityError:
            raise ValueError(f"เลขที่ '{rec['no']}' มีอยู่แล้ว")
        logging.info("แก้ไข id=%s ที่=%s", rid, rec["no"])

    def delete(self, rid: int) -> None:
        self._run(lambda: (self.conn.execute("DELETE FROM deeka WHERE id=?", (rid,)), self.conn.commit()))
        logging.info("ลบ id=%s", rid)

    def get(self, rid: int):
        return self.conn.execute("SELECT * FROM deeka WHERE id=?", (rid,)).fetchone()

    def search(self, keyword: str = ""):
        k = f"%{keyword.strip()}%"
        return self.conn.execute(
            "SELECT * FROM deeka WHERE no LIKE ? OR subject LIKE ? OR plan LIKE ? "
            "OR task LIKE ? OR expense_type LIKE ? OR expense_item LIKE ? OR note LIKE ? "
            "ORDER BY CAST(no AS INTEGER), no", (k,) * 7).fetchall()

    def backup(self, folder: Path, keep: int = 0) -> Path:
        """สำรองฐานข้อมูล; keep>0 = เก็บไฟล์สำรองล่าสุดไว้กี่ไฟล์ (ที่เก่ากว่าลบทิ้ง)"""
        folder.mkdir(exist_ok=True)
        dest = folder / f"deeka_{datetime.now():%Y%m%d_%H%M%S}.db"
        self.conn.commit()
        shutil.copy2(self.path, dest)
        logging.info("สำรองข้อมูล -> %s", dest)
        if keep > 0:
            for old in sorted(folder.glob("deeka_*.db"))[:-keep]:
                try:
                    old.unlink()
                    logging.info("ลบไฟล์สำรองเก่า %s", old.name)
                except OSError:
                    logging.warning("ลบไฟล์สำรองเก่าไม่ได้: %s", old)
        return dest



# ---------------------------------------------------------------- สถานะ / ตัวกรอง
ST_WAIT, ST_SENT, ST_DONE = "รอส่งมอบ", "ส่งมอบแล้ว", "รับมอบแล้ว"
STATUSES = [ST_WAIT, ST_SENT, ST_DONE]
ALL = "ทั้งหมด"
THAI_MONTHS = ["", "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
               "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"]


def status_of(r) -> str:
    """สถานะคำนวณเอง: มีวันที่รับมอบ หรือ ติ๊ก ✓ ผู้รับมอบ = รับมอบแล้ว ; มีวันที่ส่งมอบ หรือ ติ๊ก ✓ ผู้ส่งมอบ = ส่งมอบแล้ว ; ไม่มีเลย = รอส่งมอบ"""
    if r["receive"] or tick_of(r["receiver"]) == TICK_YES:
        return ST_DONE
    if r["handover"] or tick_of(r["sender"]) == TICK_YES:
        return ST_SENT
    return ST_WAIT


def fiscal_year(iso: str) -> int:
    """ปีงบประมาณ (พ.ศ.) เริ่ม 1 ต.ค. เช่น 15/10/2568 -> 2569"""
    d = date.fromisoformat(iso)
    return d.year + 543 + (1 if d.month >= 10 else 0)


def parse_filters(raw: dict) -> dict:
    """แปลงค่าจากช่องตัวกรอง (ข้อความ) -> dict พร้อมใช้ ; ค่า 'ทั้งหมด'/ว่าง = ไม่กรอง"""
    f = {k: ("" if raw.get(k, "") in (ALL, None) else str(raw.get(k, "")).strip())
         for k in ("fy", "plan", "expense_type", "status")}
    try:
        d1, d2 = parse_thai_date(raw.get("date_from")), parse_thai_date(raw.get("date_to"))
    except ValueError as e:
        raise ValueError(f"ตัวกรองวันที่: {e}")
    if d1 and d2 and d2 < d1:
        raise ValueError("ตัวกรองวันที่: 'ถึงวันที่' ต้องไม่ก่อน 'ตั้งแต่วันที่'")
    f["date_from"] = d1.isoformat() if d1 else ""
    f["date_to"] = d2.isoformat() if d2 else ""
    if f["fy"] and not f["fy"].isdigit():
        raise ValueError("ปีงบประมาณต้องเป็นตัวเลข เช่น 2569")
    return f


def filter_rows(rows, f: dict):
    out = []
    for r in rows:
        if f.get("date_from") and r["created"] < f["date_from"]:
            continue
        if f.get("date_to") and r["created"] > f["date_to"]:
            continue
        if f.get("fy") and fiscal_year(r["created"]) != int(f["fy"]):
            continue
        if f.get("plan") and r["plan"] != f["plan"]:
            continue
        if f.get("expense_type") and r["expense_type"] != f["expense_type"]:
            continue
        if f.get("status") and status_of(r) != f["status"]:
            continue
        out.append(r)
    return out


def describe_filters(f: dict, keyword: str = "") -> str:
    parts = []
    if keyword.strip():
        parts.append(f"คำค้น \"{keyword.strip()}\"")
    if f.get("fy"):
        parts.append(f"ปีงบประมาณ {f['fy']}")
    if f.get("date_from") or f.get("date_to"):
        parts.append(f"วันที่จัดทำ {fmt_thai_date(f.get('date_from')) or '...'} ถึง "
                     f"{fmt_thai_date(f.get('date_to')) or '...'}")
    for key, label in (("plan", "แผนงาน"), ("expense_type", "ประเภท"), ("status", "สถานะ")):
        if f.get(key):
            parts.append(f"{label}: {f[key]}")
    return " | ".join(parts)   # ว่าง = ไม่มีตัวกรอง (ไม่ต้องพิมพ์บรรทัดตัวกรอง)


def export_csv(rows, dest: Path) -> int:
    """ส่งออกเป็น CSV (UTF-8 มี BOM เพื่อให้ Excel อ่านภาษาไทยได้)"""
    head = ["ที่", "วันที่จัดทำ", "ฎีกาเรื่อง", "แผนงาน", "งาน", "รายจ่าย", "ประเภทรายจ่าย", "จำนวนเงิน",
            "ผู้ส่งมอบ", "วันที่ส่งมอบ", "ผู้รับมอบ", "วันที่รับมอบ", "สถานะ", "หมายเหตุ"]
    with open(dest, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(head)
        for r in rows:
            w.writerow([r["no"], fmt_thai_date(r["created"]), r["subject"], r["plan"],
                        r["task"], r["expense_type"], r["expense_item"], f"{r['amount'] / 100:.2f}", tick_of(r["sender"]),
                        fmt_thai_date(r["handover"]), tick_of(r["receiver"]), fmt_thai_date(r["receive"]),
                        status_of(r), r["note"]])
    logging.info("ส่งออก %s รายการ -> %s", len(rows), dest)
    return len(rows)


# ---------------------------------------------------------------- รายงาน (HTML สำหรับพิมพ์)
_CSS = """
body { font-family: "TH Sarabun New","Sarabun","Tahoma",sans-serif; font-size: 13pt; }
h1 { text-align:center; font-size: 18pt; margin: 0 0 4px; }
h2 { font-size: 14pt; margin: 14px 0 4px; }
.meta { text-align:center; margin-bottom: 8px; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #000; padding: 3px 5px; font-size: 9.5pt; vertical-align: top; }
th { background: #eee; } thead { display: table-header-group; } tr { page-break-inside: avoid; }
.c { text-align:center; } .r { text-align:right; white-space: nowrap; }
tfoot td { font-weight: bold; }
"""


def _page(title, subtitle, rows_count, inner, landscape=True):
    from html import escape as e
    size = "A4 landscape" if landscape else "A4 portrait"
    return f"""<!doctype html><html lang="th"><head><meta charset="utf-8">
<title>{e(title)}</title><style>@page {{ size: {size}; margin: 10mm; }}{_CSS}</style>
</head><body onload="window.print()">
<h1>{e(title)}</h1>
<div class="meta">{("ตัวกรอง: " + e(subtitle) + "<br>") if subtitle else ""}พิมพ์เมื่อ {fmt_thai_date(date.today().isoformat())}
 &nbsp;|&nbsp; จำนวน {rows_count} รายการ</div>
{inner}</body></html>"""


def build_print_html(rows, title="ทะเบียนการจัดทำฎีกา", subtitle="") -> str:
    """ทะเบียน: A4 แนวนอน"""
    from html import escape as e
    total = sum(r["amount"] for r in rows)
    body = "".join(
        "<tr>" + "".join(f"<td{c}>{e(str(v))}</td>" for v, c in (
            (r["no"], ' class="c"'), (fmt_thai_date(r["created"]), ' class="c"'),
            (r["subject"], ""), (r["plan"], ""), (r["task"], ""), (r["expense_type"], ""), (r["expense_item"], ""),
            (fmt_amount(r["amount"]), ' class="r"'),
            (tick_of(r["sender"]), ' class="c"'), (fmt_thai_date(r["handover"]), ' class="c"'),
            (tick_of(r["receiver"]), ' class="c"'), (fmt_thai_date(r["receive"]), ' class="c"'),
            (r["note"], ""))) + "</tr>" for r in rows)
    inner = f"""<table><thead><tr><th>ที่</th><th>วันที่จัดทำ</th><th>ฎีกาเรื่อง</th><th>แผนงาน</th><th>งาน</th>
<th>รายจ่าย</th><th>ประเภทรายจ่าย</th><th>จำนวนเงิน</th><th>ผู้ส่งมอบ</th><th>วันที่ส่งมอบ</th>
<th>ผู้รับมอบ</th><th>วันที่รับมอบ</th><th>หมายเหตุ</th></tr></thead>
<tbody>{body}</tbody>
<tfoot><tr><td colspan="7" class="r">รวมทั้งสิ้น</td><td class="r">{fmt_amount(total)}</td><td colspan="5"></td></tr></tfoot>
</table>"""
    return _page(title, subtitle, len(rows), inner, landscape=True)


def group_totals(rows, keyfn):
    """รวมจำนวนรายการ/ยอดเงิน ตามกลุ่ม -> [(กลุ่ม, จำนวน, ยอดเงิน)] เรียงตามกลุ่ม"""
    acc = {}
    for r in rows:
        k = keyfn(r)
        c, t = acc.get(k, (0, 0))
        acc[k] = (c + 1, t + r["amount"])
    return [(k, c, t) for k, (c, t) in sorted(acc.items())]


def summary_sections(rows):
    """ส่วนสรุปทั้งหมด -> [(หัวข้อ, [(ชื่อกลุ่ม, จำนวน, ยอดเงิน)])]"""
    order = {s: i for i, s in enumerate(STATUSES)}
    by_status = [(STATUSES[k], c, t) for k, c, t in group_totals(rows, lambda r: order[status_of(r)])]

    def month_label(ym):
        y, m = ym.split("-")
        return f"{THAI_MONTHS[int(m)]} {int(y) + 543}"

    return [
        ("สรุปตามสถานะ", by_status),
        ("สรุปตามแผนงาน", group_totals(rows, lambda r: r["plan"])),
        ("สรุปตามแผนงานและงาน", group_totals(rows, lambda r: r["plan"] + (" › " + r["task"] if r["task"] else ""))),
        ("สรุปตามรายจ่าย", group_totals(rows, lambda r: r["expense_type"])),
        ("สรุปตามรายจ่ายและประเภทรายจ่าย",
         group_totals(rows, lambda r: r["expense_type"] + (" › " + r["expense_item"] if r["expense_item"] else ""))),
        ("สรุปตามเดือนที่จัดทำ", [(month_label(k), c, t)
                                   for k, c, t in group_totals(rows, lambda r: r["created"][:7])]),
    ]


def build_summary_html(rows, subtitle="") -> str:
    """รายงานสรุปยอด: A4 แนวตั้ง"""
    from html import escape as e
    parts = []
    for title, data in summary_sections(rows):
        body = "".join(f'<tr><td>{e(str(k))}</td><td class="c">{c}</td><td class="r">{fmt_amount(t)}</td></tr>'
                       for k, c, t in data)
        parts.append(f"<h2>{e(title)}</h2><table><thead><tr><th>รายการ</th><th>จำนวนฎีกา</th>"
                     f"<th>จำนวนเงิน (บาท)</th></tr></thead><tbody>{body}</tbody></table>")
    total = sum(r["amount"] for r in rows)
    parts.append(f'<h2>รวมทั้งสิ้น</h2><table><tr><td>ฎีกาทั้งหมด {len(rows)} ฉบับ</td>'
                 f'<td class="r">{fmt_amount(total)} บาท</td></tr></table>')
    return _page("รายงานสรุปทะเบียนการจัดทำฎีกา", subtitle, len(rows), "".join(parts), landscape=False)




# ---------------------------------------------------------------- GUI
# สีของธีม (โทนสว่าง สไตล์แดชบอร์ด)
C_BG, C_CARD, C_BORDER = "#F1F5F9", "#FFFFFF", "#E2E8F0"
C_TEXT, C_MUTED = "#0F172A", "#64748B"
C_PRIMARY, C_PRIMARY_HOVER, C_PRIMARY_DOWN = "#2563EB", "#1D4ED8", "#1E40AF"
C_DANGER, C_DANGER_BG = "#DC2626", "#FEF2F2"
C_WAIT, C_SENT, C_DONE = "#F59E0B", "#3B82F6", "#22C55E"           # สีเน้นของการ์ดสถานะ
ROW_WAIT, ROW_SENT, ROW_DONE = "#FFF8E8", "#EEF4FF", "#EDF9F0"     # สีพื้นแถวในตาราง


def apply_theme(root):
    """ตั้งธีมทั้งโปรแกรม: ฟอนต์ สี ปุ่ม ช่องกรอก ตาราง -> คืน (family, ขนาดฟอนต์พื้นฐาน)"""
    from tkinter import font as tkfont
    from tkinter import ttk

    fams = set(tkfont.families(root))
    prefs = {"win32": ["Leelawadee UI", "Segoe UI", "Tahoma"],
             "darwin": []}.get(sys.platform, ["Noto Sans Thai", "Loma", "Sarabun", "DejaVu Sans"])
    default = tkfont.nametofont("TkDefaultFont")
    family = next((p for p in prefs if p in fams), default.actual("family"))
    base = {"darwin": 13, "win32": 10}.get(sys.platform, 11)
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        tkfont.nametofont(name).configure(family=family, size=base)
    root.option_add("*TCombobox*Listbox.font", (family, base))
    root.option_add("*TCombobox*Listbox.background", C_CARD)
    root.option_add("*TCombobox*Listbox.selectBackground", C_PRIMARY)
    root.option_add("*TCombobox*Listbox.selectForeground", "#FFFFFF")
    root.configure(bg=C_BG)

    st = ttk.Style(root)
    st.theme_use("clam")      # ธีมเดียวที่กำหนดสีปุ่ม/ช่องกรอกได้เหมือนกันทุกระบบ
    st.configure(".", background=C_BG, foreground=C_TEXT, font=(family, base),
                 bordercolor=C_BORDER, lightcolor=C_BG, darkcolor=C_BG, focuscolor=C_BG)

    # ป้ายข้อความ
    st.configure("TLabel", background=C_BG, foreground=C_TEXT)
    st.configure("Card.TLabel", background=C_CARD)
    st.configure("Field.TLabel", background=C_CARD, foreground=C_MUTED, font=(family, base - 1))
    st.configure("Muted.TLabel", foreground=C_MUTED, font=(family, base - 1))
    st.configure("H1.TLabel", font=(family, base + 9, "bold"))
    st.configure("H2.TLabel", background=C_CARD, font=(family, base + 1, "bold"))

    # ช่องกรอก / ดรอปดาวน์
    for name in ("App.TEntry", "TCombobox"):
        st.configure(name, fieldbackground=C_CARD, background=C_CARD, foreground=C_TEXT,
                     bordercolor="#CBD5E1", lightcolor="#CBD5E1", darkcolor="#CBD5E1",
                     padding=(8, 6), arrowcolor=C_MUTED, insertcolor=C_TEXT)
        st.map(name, bordercolor=[("focus", C_PRIMARY)], lightcolor=[("focus", C_PRIMARY)],
               darkcolor=[("focus", C_PRIMARY)])
    st.map("TCombobox", fieldbackground=[("readonly", C_CARD)], foreground=[("readonly", C_TEXT)],
           selectbackground=[("readonly", C_CARD)], selectforeground=[("readonly", C_TEXT)])

    # ปุ่ม
    pad = (16, 7)
    st.configure("TButton", padding=pad, relief="solid", borderwidth=1, background=C_CARD,
                 foreground=C_TEXT, bordercolor="#CBD5E1", lightcolor="#CBD5E1", darkcolor="#CBD5E1")
    st.map("TButton", background=[("pressed", "#E2E8F0"), ("active", "#F8FAFC")])
    st.configure("Primary.TButton", background=C_PRIMARY, foreground="#FFFFFF", bordercolor=C_PRIMARY,
                 lightcolor=C_PRIMARY, darkcolor=C_PRIMARY, font=(family, base, "bold"), padding=(20, 7))
    st.map("Primary.TButton", background=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)],
           bordercolor=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)],
           lightcolor=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)],
           darkcolor=[("pressed", C_PRIMARY_DOWN), ("active", C_PRIMARY_HOVER)])
    st.configure("Danger.TButton", foreground=C_DANGER, bordercolor="#FECACA",
                 lightcolor="#FECACA", darkcolor="#FECACA")
    st.map("Danger.TButton", background=[("pressed", "#FEE2E2"), ("active", C_DANGER_BG)])

    # ปุ่มเลือก ✓ / ✗ / ว่าง
    for name, on in (("Blank", "#E2E8F0"), ("Yes", "#DCFCE7"), ("No", "#FEE2E2")):
        st.configure(f"{name}.Toolbutton", background=C_CARD, foreground=C_MUTED, padding=(14, 5),
                     relief="solid", borderwidth=1, bordercolor="#CBD5E1", lightcolor="#CBD5E1",
                     darkcolor="#CBD5E1", anchor="center")
        st.map(f"{name}.Toolbutton", background=[("selected", on), ("active", "#F8FAFC")],
               foreground=[("selected", {"Blank": C_TEXT, "Yes": "#15803D", "No": C_DANGER}[name])],
               bordercolor=[("selected", {"Blank": "#94A3B8", "Yes": "#22C55E", "No": "#F87171"}[name])])

    # ตาราง
    st.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])   # ตัดขอบเดิมออก
    st.configure("Treeview", background=C_CARD, fieldbackground=C_CARD, foreground=C_TEXT,
                 rowheight=int(base * 2.7), borderwidth=0)
    st.map("Treeview", background=[("selected", "#BFDBFE")], foreground=[("selected", C_TEXT)])
    st.configure("Treeview.Heading", background="#F8FAFC", foreground=C_MUTED, relief="flat",
                 font=(family, base - 1, "bold"), padding=(8, 8), bordercolor=C_BORDER,
                 lightcolor="#F8FAFC", darkcolor="#F8FAFC")
    st.map("Treeview.Heading", background=[("active", "#EEF2F7")])
    st.configure("Vertical.TScrollbar", background="#CBD5E1", troughcolor=C_CARD, bordercolor=C_CARD,
                 arrowcolor=C_CARD, lightcolor="#CBD5E1", darkcolor="#CBD5E1", gripcount=0)
    st.map("Vertical.TScrollbar", background=[("active", "#94A3B8")])
    st.configure("Horizontal.TScrollbar", background="#CBD5E1", troughcolor=C_CARD, bordercolor=C_CARD,
                 arrowcolor=C_CARD, lightcolor="#CBD5E1", darkcolor="#CBD5E1", gripcount=0)
    st.map("Horizontal.TScrollbar", background=[("active", "#94A3B8")])
    return family, base


def run_gui():
    import tkinter as tk
    import webbrowser
    from tkinter import filedialog, messagebox, ttk

    if sys.platform == "win32":      # ให้ตัวหนังสือคมบนจอ Windows ความละเอียดสูง
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

    cfg = load_config()
    setup_logging(cfg)
    db = Database(BASE_DIR / cfg["files"]["database"],
                  cfg.getint("retry", "times"), cfg.getfloat("retry", "wait_seconds"))
    plans, tasks_of, types, items_of = load_lists(BASE_DIR / cfg.get("files", "lists", fallback="lists.txt"))
    backup_dir = BASE_DIR / cfg["files"]["backup_dir"]
    backup_keep = cfg.getint("files", "backup_keep", fallback=30)
    dirty = {"v": False}   # มีการแก้ไขข้อมูลตั้งแต่สำรองครั้งล่าสุดหรือไม่

    root = tk.Tk()
    root.title("ทะเบียนการจัดทำฎีกา")
    family, base = apply_theme(root)
    root.minsize(1100, 700)

    def tidy_date(var):
        """พิมพ์ 4/11/69 แล้วออกจากช่อง -> แปลงเป็น 4 พ.ย. 69 ให้เอง (ถ้ารูปแบบผิดปล่อยไว้ให้ตรวจตอนบันทึก)"""
        try:
            d = parse_thai_date(var.get())
        except ValueError:
            return
        if d:
            var.set(fmt_thai_date(d.isoformat()))

    def card(parent, **kw):
        return tk.Frame(parent, bg=C_CARD, highlightbackground=C_BORDER, highlightcolor=C_BORDER,
                        highlightthickness=1, **kw)

    # ----- ส่วนหัว
    status = tk.StringVar()      # ข้อความแจ้งผลด้านล่าง
    footer = ttk.Label(root, textvariable=status, style="Muted.TLabel")
    footer.pack(side="bottom", fill="x", padx=26, pady=(0, 8))

    head = ttk.Frame(root)
    head.pack(fill="x", padx=24, pady=(14, 8))
    ttk.Label(head, text="ทะเบียนการจัดทำฎีกา", style="H1.TLabel").pack(side="left")
    ttk.Label(head, text="บันทึก ติดตามสถานะ และพิมพ์รายงานฎีกา", style="Muted.TLabel").pack(
        side="left", padx=(14, 0), pady=(10, 0))

    # ----- การ์ดสรุปสถานะ (คลิกเพื่อกรองตามสถานะได้)
    flt = {k: tk.StringVar(value=ALL if k in ("fy", "plan", "expense_type", "status") else "")
           for k in ("fy", "plan", "expense_type", "status", "date_from", "date_to")}
    stat_n = {k: tk.StringVar(value="0") for k in ("all", *STATUSES)}
    stat_amt = {k: tk.StringVar(value="0.00 บาท") for k in ("all", *STATUSES)}
    stat_cards = {}

    def pick_status(key):
        flt["status"].set(ALL if key == "all" else key)
        reload()

    cards_row = ttk.Frame(root)
    cards_row.pack(fill="x", padx=24, pady=(0, 8))
    for i, (key, title, accent) in enumerate((("all", "ฎีกาทั้งหมด", C_PRIMARY), (ST_WAIT, ST_WAIT, C_WAIT),
                                              (ST_SENT, ST_SENT, C_SENT), (ST_DONE, ST_DONE, C_DONE))):
        cards_row.columnconfigure(i, weight=1, uniform="stat")
        f = card(cards_row, cursor="hand2")
        f.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 3 else 6))
        strip = tk.Frame(f, bg=accent, width=5)
        strip.pack(side="left", fill="y")
        body = tk.Frame(f, bg=C_CARD)
        body.pack(side="left", fill="both", expand=True, padx=14, pady=4)
        tk.Label(body, text=title, bg=C_CARD, fg=C_MUTED, font=(family, base - 1)).pack(anchor="w")
        line = tk.Frame(body, bg=C_CARD)
        line.pack(anchor="w", fill="x")
        tk.Label(line, textvariable=stat_n[key], bg=C_CARD, fg=C_TEXT,
                 font=(family, base + 6, "bold")).pack(side="left")
        tk.Label(line, textvariable=stat_amt[key], bg=C_CARD, fg=C_MUTED,
                 font=(family, base - 1)).pack(side="left", padx=(10, 0), pady=(5, 0))

        def bind_all(w, k=key):
            w.bind("<Button-1>", lambda _e: pick_status(k))
            for ch in w.winfo_children():
                bind_all(ch, k)
        bind_all(f)
        stat_cards[key] = f

    # ----- ฟอร์มกรอกข้อมูล
    vars_ = {k: tk.StringVar() for k in
             ("no", "created", "subject", "plan", "task", "expense_type", "expense_item", "amount",
              "sender", "handover", "receiver", "receive", "note")}
    form_card = card(root)
    form_card.pack(fill="x", padx=24, pady=(0, 8))
    form_title = tk.StringVar(value="เพิ่มฎีกาใหม่")
    ttk.Label(form_card, textvariable=form_title, style="H2.TLabel").pack(anchor="w", padx=18, pady=(10, 0))
    form = tk.Frame(form_card, bg=C_CARD)
    form.pack(fill="x", padx=12, pady=(0, 4))
    for c in range(6):
        form.columnconfigure(c, weight=1, uniform="f")

    def field(label, key, r, c, span=1, values=None):
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        w = (ttk.Combobox(form, textvariable=vars_[key], values=values)
             if values is not None else ttk.Entry(form, textvariable=vars_[key], style="App.TEntry"))
        w.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="ew", padx=6)
        if key in ("created", "handover", "receive"):
            w.bind("<FocusOut>", lambda _e, v=vars_[key]: tidy_date(v))
        return w

    def tickfield(label, key, r, c, span=1):
        """เลือก ✓ (ถูก) / ✗ (กากบาท) / ว่าง แทนการพิมพ์ชื่อ"""
        ttk.Label(form, text=label, style="Field.TLabel").grid(
            row=r * 2, column=c, columnspan=span, sticky="w", padx=6, pady=(4, 0))
        box = tk.Frame(form, bg=C_CARD)
        box.grid(row=r * 2 + 1, column=c, columnspan=span, sticky="w", padx=6)
        for text, val, sty in (("ว่าง", "", "Blank"), ("✓ ถูก", TICK_YES, "Yes"), ("✗ กากบาท", TICK_NO, "No")):
            ttk.Radiobutton(box, text=text, value=val, variable=vars_[key],
                            style=f"{sty}.Toolbutton").pack(side="left", padx=(0, 4))

    # จัดวางบนตาราง 6 คอลัมน์ (แถวละ 6 ส่วน)
    field("ที่ *", "no", 0, 0)
    field("วันที่จัดทำ * (เช่น 4 พ.ย. 69)", "created", 0, 1)
    subject_entry = field("ฎีกาเรื่อง *", "subject", 0, 2, span=2)
    field("หมายเหตุ", "note", 0, 4, span=2)
    field("แผนงาน *", "plan", 1, 0, span=3, values=plans)
    task_box = field("งาน (เลือกแผนงานก่อน)", "task", 1, 3, span=3, values=[])
    field("รายจ่าย *", "expense_type", 2, 0, span=2, values=types)
    item_box = field("ประเภทรายจ่าย (เลือกรายจ่ายก่อน)", "expense_item", 2, 2, span=3, values=[])
    field("จำนวนเงิน (บาท) *", "amount", 2, 5)
    tickfield("ผู้ส่งมอบ", "sender", 3, 0, span=2)
    field("วันที่ส่งมอบ (เช่น 4 พ.ย. 69)", "handover", 3, 2)
    tickfield("ผู้รับมอบ", "receiver", 3, 3, span=2)
    field("วันที่รับมอบ (เช่น 4 พ.ย. 69)", "receive", 3, 5)

    def link(parent_key, child_key, child_box, mapping):
        """ช่องลูก (งาน / รายการรายจ่าย) แสดงเฉพาะตัวเลือกของช่องแม่ที่เลือกอยู่"""
        def on_change(*_):
            opts = mapping.get(vars_[parent_key].get(), [])
            child_box["values"] = opts
            cur = vars_[child_key].get()
            if cur and opts and cur not in opts:
                vars_[child_key].set("")
        vars_[parent_key].trace_add("write", on_change)

    link("plan", "task", task_box, tasks_of)
    link("expense_type", "expense_item", item_box, items_of)

    state = {"id": None}   # id ของรายการที่กำลังแก้ไข (None = เพิ่มใหม่)
    save_label = tk.StringVar(value="บันทึก")
    btns = tk.Frame(form_card, bg=C_CARD)
    btns.pack(fill="x", padx=18, pady=(6, 12))

    # ----- ตารางรายการ + ตัวกรอง
    table_card = card(root)
    table_card.pack(fill="both", expand=True, padx=24, pady=(0, 6))
    search_var = tk.StringVar()

    tools = tk.Frame(table_card, bg=C_CARD)
    tools.pack(fill="x", padx=14, pady=(10, 4))
    ttk.Label(tools, text="รายการฎีกา", style="H2.TLabel").pack(side="left", padx=(0, 16))
    search_entry = ttk.Entry(tools, textvariable=search_var, style="App.TEntry", width=26)
    search_entry.pack(side="left")
    ttk.Button(tools, text="ค้นหา", command=lambda: reload()).pack(side="left", padx=(6, 0))
    ttk.Button(tools, text="ล้างตัวกรอง", command=lambda: clear_filters()).pack(side="left", padx=(6, 0))
    tools_right = tk.Frame(tools, bg=C_CARD)
    tools_right.pack(side="right")

    filters = tk.Frame(table_card, bg=C_CARD)
    filters.pack(fill="x", padx=14, pady=(2, 8))
    combos = {}

    def fcombo(label, key, width):
        ttk.Label(filters, text=label, style="Field.TLabel").pack(side="left", padx=(0, 4))
        c = ttk.Combobox(filters, textvariable=flt[key], width=width, state="readonly")
        c.pack(side="left", padx=(0, 12))
        c.bind("<<ComboboxSelected>>", lambda _: reload())
        combos[key] = c

    def fentry(label, key):
        ttk.Label(filters, text=label, style="Field.TLabel").pack(side="left", padx=(0, 4))
        en = ttk.Entry(filters, textvariable=flt[key], style="App.TEntry", width=11)
        en.pack(side="left", padx=(0, 12))
        en.bind("<Return>", lambda _: reload())
        en.bind("<FocusOut>", lambda _e, v=flt[key]: tidy_date(v))

    fcombo("ปีงบประมาณ", "fy", 8)
    fentry("วันที่จัดทำ ตั้งแต่", "date_from")
    fentry("ถึง", "date_to")
    fcombo("แผนงาน", "plan", 18)
    fcombo("รายจ่าย", "expense_type", 14)
    fcombo("สถานะ", "status", 11)

    def clear_filters():
        for k, v in flt.items():
            v.set(ALL if k in ("fy", "plan", "expense_type", "status") else "")
        search_var.set("")
        reload()

    ttk.Separator(table_card, orient="horizontal").pack(fill="x")

    heads = [("no", "ที่", 52, "w", False), ("created", "วันที่จัดทำ", 100, "w", False),
             ("subject", "ฎีกาเรื่อง", 200, "w", True), ("plan", "แผนงาน", 150, "w", False), ("task", "งาน", 170, "w", False),
             ("expense_type", "รายจ่าย", 115, "w", False), ("expense_item", "ประเภทรายจ่าย", 190, "w", False), ("amount", "จำนวนเงิน", 110, "e", False),
             ("sender", "ผู้ส่งมอบ", 80, "center", False), ("handover", "ส่งมอบ", 90, "center", False),
             ("receiver", "ผู้รับมอบ", 80, "center", False), ("receive", "รับมอบ", 90, "center", False),
             ("status", "สถานะ", 105, "w", False), ("note", "หมายเหตุ", 110, "w", True)]
    tf = tk.Frame(table_card, bg=C_CARD)
    tf.pack(fill="both", expand=True)
    tree = ttk.Treeview(tf, columns=[h[0] for h in heads], show="headings", selectmode="browse")
    for key, text, w, anchor, stretch in heads:
        tree.heading(key, text=text, anchor="e" if anchor == "e" else "w")
        tree.column(key, width=w, minwidth=50, anchor=anchor, stretch=stretch)
    sb = ttk.Scrollbar(tf, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(tf, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=sb.set, xscrollcommand=hsb.set)
    tf.rowconfigure(0, weight=1)
    tf.columnconfigure(0, weight=1)
    tree.grid(row=0, column=0, sticky="nsew")
    sb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    tag_of = {ST_WAIT: "wait", ST_SENT: "sent", ST_DONE: "done"}
    tree.tag_configure("wait", background=ROW_WAIT)
    tree.tag_configure("sent", background=ROW_SENT)
    tree.tag_configure("done", background=ROW_DONE)
    empty = tk.Label(tf, text="ยังไม่มีรายการ", bg=C_CARD, fg=C_MUTED, font=(family, base + 1))

    # ----- การทำงาน
    def current_rows():
        """รายการตามคำค้น + ตัวกรอง ; raise ValueError ถ้าตัวกรองผิดรูปแบบ"""
        f = parse_filters({k: v.get() for k, v in flt.items()})
        return filter_rows(db.search(search_var.get()), f), f

    def refresh_filter_lists():
        rows = db.search("")
        combos["fy"]["values"] = [ALL] + [str(y) for y in sorted({fiscal_year(r["created"]) for r in rows}, reverse=True)]
        combos["plan"]["values"] = [ALL] + sorted(set(plans) | {r["plan"] for r in rows})
        combos["expense_type"]["values"] = [ALL] + sorted(set(types) | {r["expense_type"] for r in rows})
        combos["status"]["values"] = [ALL] + STATUSES

    def reload(_=None):
        try:
            f = parse_filters({k: v.get() for k, v in flt.items()})
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return []
        refresh_filter_lists()
        # การ์ดสรุปนับจากตัวกรองทุกอย่าง "ยกเว้นสถานะ" เพื่อให้เทียบสถานะกันได้
        base_rows = filter_rows(db.search(search_var.get()), {**f, "status": ""})
        rows = [r for r in base_rows if not f["status"] or status_of(r) == f["status"]]
        tree.delete(*tree.get_children())
        for r in rows:
            st = status_of(r)
            tree.insert("", "end", iid=str(r["id"]), tags=(tag_of[st],), values=(
                r["no"], fmt_thai_date(r["created"]), r["subject"], r["plan"], r["task"], r["expense_type"], r["expense_item"],
                fmt_amount(r["amount"]), tick_of(r["sender"]), fmt_thai_date(r["handover"]),
                tick_of(r["receiver"]), fmt_thai_date(r["receive"]), st, r["note"]))
        counts = {s: [0, 0] for s in STATUSES}
        for r in base_rows:
            c = counts[status_of(r)]
            c[0] += 1
            c[1] += r["amount"]
        stat_n["all"].set(f"{len(base_rows)} ฉบับ")
        stat_amt["all"].set(f"{fmt_amount(sum(r['amount'] for r in base_rows))} บาท")
        for s in STATUSES:
            stat_n[s].set(f"{counts[s][0]} ฉบับ")
            stat_amt[s].set(f"{fmt_amount(counts[s][1])} บาท")
        active = f["status"] or "all"
        for key, fr in stat_cards.items():
            fr.configure(highlightbackground=C_PRIMARY if key == active else C_BORDER,
                         highlightthickness=2 if key == active else 1)
        if rows:
            empty.place_forget()
        else:
            empty.configure(text="ไม่พบรายการตามเงื่อนไข" if db.search("") else "ยังไม่มีรายการ — กรอกข้อมูลด้านบนแล้วกด บันทึก")
            empty.place(relx=0.5, rely=0.45, anchor="center")
        status.set(f"แสดง {len(rows)} รายการ   รวมเงิน {fmt_amount(sum(r['amount'] for r in rows))} บาท")
        return rows

    def set_mode(editing_no=None):
        if editing_no is None:
            form_title.set("เพิ่มฎีกาใหม่")
            save_label.set("บันทึก")
        else:
            form_title.set(f"กำลังแก้ไขฎีกา ที่ {editing_no}")
            save_label.set("บันทึกการแก้ไข")

    def clear():
        state["id"] = None
        for v in vars_.values():
            v.set("")
        vars_["no"].set(db.next_no())
        vars_["created"].set(fmt_thai_date(date.today().isoformat()))
        tree.selection_remove(tree.selection())
        set_mode()
        subject_entry.focus_set()

    def on_select(_=None):
        sel = tree.selection()
        if not sel:
            return
        r = db.get(int(sel[0]))
        state["id"] = r["id"]
        for k in vars_:
            val = r[k]
            if k in ("created", "handover", "receive"):
                val = fmt_thai_date(val)
            elif k == "amount":
                val = f"{val / 100:.2f}"
            elif k in ("sender", "receiver"):
                val = tick_of(val)
            vars_[k].set(val)
        set_mode(r["no"])

    def save(_=None):
        try:
            rec = validate({k: v.get() for k, v in vars_.items()})
            if state["id"] is None:
                db.add(rec)
                msg = f"เพิ่มฎีกา ที่ {rec['no']} แล้ว"
            else:
                db.update(state["id"], rec)
                msg = f"แก้ไขฎีกา ที่ {rec['no']} แล้ว"
        except ValueError as ex:
            messagebox.showwarning("ข้อมูลไม่ถูกต้อง", str(ex))
            return
        except sqlite3.Error as ex:
            logging.exception("บันทึกไม่สำเร็จ")
            messagebox.showerror("บันทึกไม่สำเร็จ", f"ฐานข้อมูลมีปัญหา: {ex}\nดูรายละเอียดในไฟล์ log")
            return
        dirty["v"] = True
        reload()
        clear()
        status.set(f"✓ {msg}   |   {status.get()}")

    def delete():
        if state["id"] is None:
            messagebox.showinfo("ลบ", "กรุณาเลือกรายการในตารางก่อน")
            return
        if messagebox.askyesno("ยืนยัน", "ลบรายการนี้ถาวรหรือไม่?"):
            db.delete(state["id"])
            dirty["v"] = True
            reload()
            clear()

    def do_export():
        try:
            rows, _f = current_rows()
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return
        folder = BASE_DIR / cfg["files"]["export_dir"]
        folder.mkdir(exist_ok=True)
        dest = filedialog.asksaveasfilename(
            initialdir=folder, initialfile=f"deeka_{datetime.now():%Y%m%d}.csv",
            defaultextension=".csv", filetypes=[("CSV (เปิดด้วย Excel)", "*.csv")])
        if dest:
            n = export_csv(rows, Path(dest))
            messagebox.showinfo("ส่งออก", f"ส่งออก {n} รายการ (ตามตัวกรองที่เลือก) เรียบร้อย\n{dest}")

    def open_report(builder, filename):
        try:
            rows, f = current_rows()
        except ValueError as ex:
            messagebox.showwarning("ตัวกรองไม่ถูกต้อง", str(ex))
            return
        if not rows:
            messagebox.showinfo("พิมพ์", "ไม่มีรายการให้พิมพ์")
            return
        folder = BASE_DIR / cfg["files"]["export_dir"]
        folder.mkdir(exist_ok=True)
        dest = folder / filename
        dest.write_text(builder(rows, subtitle=describe_filters(f, search_var.get())), encoding="utf-8")
        logging.info("สร้างรายงาน %s (%s รายการ)", filename, len(rows))
        webbrowser.open(dest.as_uri())   # เปิดเบราว์เซอร์ + หน้าต่างพิมพ์ขึ้นเอง

    def do_backup():
        dest = db.backup(backup_dir, backup_keep)
        dirty["v"] = False
        messagebox.showinfo("สำรองข้อมูล", f"สำรองข้อมูลแล้ว\n{dest}")

    def on_close():
        """สำรองอัตโนมัติตอนปิดโปรแกรม (เฉพาะเมื่อมีการแก้ไขข้อมูล)"""
        if dirty["v"]:
            try:
                db.backup(backup_dir, backup_keep)
            except Exception:
                logging.exception("สำรองอัตโนมัติไม่สำเร็จ")
        try:
            db.conn.close()
        finally:
            root.destroy()

    # ----- ปุ่ม
    ttk.Button(btns, text="ลบรายการ", style="Danger.TButton", command=delete).pack(side="right")
    ttk.Button(btns, text="ล้างฟอร์ม / เพิ่มใหม่", command=clear).pack(side="right", padx=8)
    ttk.Button(btns, textvariable=save_label, style="Primary.TButton", command=save).pack(side="right")
    for text, cmd in (("สำรองข้อมูล", do_backup), ("ส่งออก CSV", do_export),
                      ("รายงานสรุป", lambda: open_report(build_summary_html, "summary_deeka.html")),
                      ("พิมพ์ทะเบียน", lambda: open_report(build_print_html, "print_deeka.html"))):
        ttk.Button(tools_right, text=text, command=cmd).pack(side="right", padx=(6, 0))

    search_entry.bind("<Return>", lambda _: reload())
    tree.bind("<<TreeviewSelect>>", on_select)
    root.bind_all("<Command-s>" if sys.platform == "darwin" else "<Control-s>", save)
    root.protocol("WM_DELETE_WINDOW", on_close)

    reload()
    clear()
    w, h = 1340, min(max(root.winfo_screenheight() - 100, 700), 980)   # สูงตามหน้าจอ เพื่อให้ตารางเห็นหลายแถว
    root.geometry(f"{w}x{h}+{max((root.winfo_screenwidth() - w) // 2, 0)}+{max((root.winfo_screenheight() - h) // 3, 0)}")
    root.mainloop()


if __name__ == "__main__":
    run_gui()