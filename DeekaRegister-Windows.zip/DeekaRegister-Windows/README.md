# โปรแกรมทะเบียนการจัดทำฎีกา

โปรแกรม Desktop สำหรับ Windows พัฒนาด้วย Python, Tkinter และ SQLite

## วิธีสร้างไฟล์ .exe บน Windows

> ต้องสร้างไฟล์ EXE บน Windows ด้วย Windows เท่านั้น (PyInstaller ไม่ได้สร้าง Windows EXE จาก macOS/Linux)

1. ติดตั้ง Python 3 จาก https://www.python.org/downloads/windows/
2. ระหว่างติดตั้งให้เลือก **Add Python to PATH**
3. แตกไฟล์ ZIP นี้ลงในโฟลเดอร์บนเครื่อง Windows
4. ดับเบิลคลิก `build_windows.bat`
5. รอจนเสร็จ แล้วเปิดไฟล์ `dist\DeekaRegister.exe`

โปรแกรมใช้ไลบรารีมาตรฐานของ Python และ SQLite ส่วน PyInstaller จะถูกติดตั้งโดยไฟล์ BAT ตอนสร้าง EXE

## ไฟล์ข้อมูล

เมื่อเปิดโปรแกรมครั้งแรก โปรแกรมจะสร้างไฟล์ประกอบในโฟลเดอร์เดียวกับ EXE เช่น

- `deeka.db` ฐานข้อมูลรายการฎีกา
- `config.ini` การตั้งค่า
- `lists.txt` รายการแผนงานและรายจ่าย
- `backup/` ไฟล์สำรองข้อมูล
- `export/` ไฟล์ส่งออก

**สำคัญ:** อย่าลบหรือย้าย `deeka.db`, `config.ini`, `lists.txt`, `backup` และ `export` หากต้องการเก็บข้อมูลเดิม ควรสำรองโฟลเดอร์เหล่านี้เป็นระยะ และไม่ควรเปิดโปรแกรมหลายเครื่องพร้อมกันโดยใช้ฐานข้อมูล SQLite เดียวกันผ่านโฟลเดอร์แชร์เครือข่าย

## อัปโหลดขึ้น GitHub

1. สมัคร/เข้าสู่ระบบที่ https://github.com
2. กดปุ่ม **New repository**
3. ตั้งชื่อ Repository เช่น `deeka-register`
4. เลือก **Private** หากมีข้อมูลภายในหน่วยงานหรือไม่ต้องการให้คนทั่วไปเห็น
5. กด **Create repository**
6. เปิดโฟลเดอร์โปรเจกต์นี้ แล้วอัปโหลดไฟล์ `deeka_register.py`, `build_windows.bat`, `README.md` และ `.gitignore` ไปที่ Repository

หรือใช้ GitHub Desktop:

1. ติดตั้ง https://desktop.github.com/
2. เลือก **File > Add local repository** แล้วเลือกโฟลเดอร์โปรเจกต์นี้
3. หากยังไม่ได้เป็น repository ให้เลือกสร้าง repository ในโฟลเดอร์นี้
4. ใส่ข้อความสรุป เช่น `Initial version`
5. กด **Commit to main** แล้วกด **Publish repository**

ไม่ควรอัปโหลดฐานข้อมูลจริง (`deeka.db`), log, ไฟล์สำรอง หรือข้อมูลส่วนบุคคลขึ้น GitHub โดยเฉพาะ Repository แบบ Public

## การใช้งานจากซอร์สโค้ด

ติดตั้ง Python 3 แล้วรัน:

```bash
python deeka_register.py
```
