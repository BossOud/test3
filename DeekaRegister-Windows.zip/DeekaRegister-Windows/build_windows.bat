@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ==========================================
echo  Build Deeka Register for Windows (.exe)
echo ==========================================

where py >nul 2>nul
if errorlevel 1 (
  echo ไม่พบ Python กรุณาติดตั้ง Python 3 จาก https://www.python.org/downloads/windows/
  echo ตอนติดตั้งให้เลือก Add Python to PATH
  pause
  exit /b 1
)

py -m pip install --upgrade pip
py -m pip install pyinstaller
if errorlevel 1 goto error

py -m PyInstaller --noconfirm --clean --onefile --windowed --name DeekaRegister deeka_register.py
if errorlevel 1 goto error

echo.
echo สร้างไฟล์สำเร็จ: dist\DeekaRegister.exe
echo คัดลอกไฟล์ EXE ไปใช้งานได้ โดยแนะนำให้วางในโฟลเดอร์ที่มีสิทธิ์เขียนไฟล์
pause
exit /b 0

:error
echo.
echo เกิดข้อผิดพลาดระหว่างสร้างโปรแกรม กรุณาตรวจสอบข้อความด้านบน
pause
exit /b 1
